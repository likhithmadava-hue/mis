package com.example.ui.screens.academic

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin
import com.example.data.model.AcademicLogEntity
import com.example.ui.components.MisCard
import com.example.ui.components.MisDividerLine
import com.example.ui.components.MisHeader
import com.example.ui.components.ProgressRail
import com.example.ui.components.PulseBeacon
import com.example.ui.theme.Academic400
import com.example.ui.theme.Academic500
import com.example.ui.theme.Academic900
import com.example.ui.theme.Academic950
import com.example.ui.theme.MisBg850
import com.example.ui.theme.MisBg900
import com.example.ui.theme.MisBg950
import com.example.ui.theme.MisBorder
import com.example.ui.theme.MisBorderStrong
import com.example.ui.theme.MisBorderSubtle
import com.example.ui.theme.MisDivider
import com.example.ui.theme.MisElevation
import com.example.ui.theme.MisInput
import com.example.ui.theme.MisRadius
import com.example.ui.theme.MisSpacing
import com.example.ui.theme.MisSurface700
import com.example.ui.theme.MisSurface750
import com.example.ui.theme.MisSurface800
import com.example.ui.theme.MisTextDim
import com.example.ui.theme.MisTextMuted
import com.example.ui.theme.MisTextPrimary
import com.example.ui.theme.MisTextSecondary
import com.example.ui.viewmodel.MisViewModel

@Composable
fun FocusTimerScreen(
    viewModel: MisViewModel,
    modifier: Modifier = Modifier
) {
    val timerState by viewModel.timerState.collectAsState()
    val academicLog by viewModel.academicLog.collectAsState()
    val habits by viewModel.allHabits.collectAsState()
    val log = academicLog ?: AcademicLogEntity(date = viewModel.todayDate)

    val minutes = timerState.secondsRemaining / 60
    val seconds = timerState.secondsRemaining % 60
    val formattedTime = String.format("%02d:%02d", minutes, seconds)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = MisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(MisSpacing.md)
    ) {
        item {
            MisHeader(
                eyebrow = "DEEP WORK OPERATIONAL SUITE",
                title = "Focus Chronometer",
                subtitle = viewModel.dateDisplayHeader
            )
        }

        // Main Timer Canvas Instrument
        item {
            val totalSeconds = 25 * 60
            val timerProgress = (timerState.secondsRemaining.toFloat() / totalSeconds.toFloat()).coerceIn(0f, 1f)
            val animatedProgress by animateFloatAsState(
                targetValue = timerProgress,
                animationSpec = tween(500),
                label = "timer_sweep"
            )

            MisCard(isFeatured = timerState.isRunning, isRaised = true) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = MisSpacing.md),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Status Beacon Row
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PulseBeacon(isActive = timerState.isRunning, color = Academic500)
                        Text(
                            text = if (timerState.isRunning) "ACTIVE TELEMETRY" else "STANDBY",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = if (timerState.isRunning) Academic400 else MisTextDim
                        )
                    }

                    Spacer(modifier = Modifier.height(MisSpacing.lg))

                    // Circular Countdown Dial Instrument
                    Box(
                        modifier = Modifier.size(240.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.size(240.dp)) {
                            val strokeWidth = 9.dp.toPx()
                            val diameter = size.minDimension - strokeWidth * 2f - 16.dp.toPx()
                            val center = Offset(size.width / 2f, size.height / 2f)
                            val radius = diameter / 2f
                            val topLeft = Offset(center.x - radius, center.y - radius)
                            val arcSize = Size(diameter, diameter)

                            // Outer Instrument Bezel Ring
                            drawCircle(
                                color = MisBorderSubtle,
                                radius = radius + strokeWidth + 4.dp.toPx(),
                                center = center,
                                style = Stroke(width = 1.dp.toPx())
                            )

                            // Background Track Ring
                            drawArc(
                                color = MisSurface700,
                                startAngle = -90f,
                                sweepAngle = 360f,
                                useCenter = false,
                                topLeft = topLeft,
                                size = arcSize,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )

                            // 60-Second Precision Chronometer Ticks
                            val numTicks = 60
                            for (i in 0 until numTicks) {
                                val tickAngle = (i * (360f / numTicks) - 90f) * (Math.PI / 180f)
                                val isMajor = i % 5 == 0
                                val tickLength = if (isMajor) 7.dp.toPx() else 3.5.dp.toPx()
                                val tickColor = if (isMajor) {
                                    if (timerState.isRunning) Academic400.copy(alpha = 0.5f) else MisTextDim.copy(alpha = 0.4f)
                                } else MisBorderSubtle
                                val startRadius = radius - strokeWidth / 2f - 4.dp.toPx()
                                val endRadius = startRadius - tickLength

                                val startX = center.x + startRadius * cos(tickAngle).toFloat()
                                val startY = center.y + startRadius * sin(tickAngle).toFloat()
                                val endX = center.x + endRadius * cos(tickAngle).toFloat()
                                val endY = center.y + endRadius * sin(tickAngle).toFloat()

                                drawLine(
                                    color = tickColor,
                                    start = Offset(startX, startY),
                                    end = Offset(endX, endY),
                                    strokeWidth = if (isMajor) 1.8.dp.toPx() else 1.dp.toPx(),
                                    cap = StrokeCap.Round
                                )
                            }

                            // Active progress sweep with cyan gradient
                            if (animatedProgress > 0f) {
                                drawArc(
                                    brush = Brush.sweepGradient(
                                        colors = listOf(
                                            Academic400.copy(alpha = 0.4f),
                                            Academic500,
                                            Academic400
                                        )
                                    ),
                                    startAngle = -90f,
                                    sweepAngle = 360f * animatedProgress,
                                    useCenter = false,
                                    topLeft = topLeft,
                                    size = arcSize,
                                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                )

                                // Glowing Instrument Pip at Tip
                                val tipAngle = (-90f + 360f * animatedProgress) * (Math.PI / 180f)
                                val tipCenter = Offset(
                                    (center.x + radius * cos(tipAngle)).toFloat(),
                                    (center.y + radius * sin(tipAngle)).toFloat()
                                )
                                drawCircle(
                                    color = Academic500.copy(alpha = 0.45f),
                                    radius = strokeWidth * 1.2f,
                                    center = tipCenter
                                )
                                drawCircle(
                                    color = Color.White,
                                    radius = strokeWidth * 0.45f,
                                    center = tipCenter
                                )
                            }
                        }

                        // Center Countdown Typography
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "ROUND ${timerState.currentRound} / 4",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 1.8.sp,
                                color = MisTextDim
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = formattedTime,
                                fontSize = 48.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = if (timerState.isRunning) Academic500 else MisTextPrimary
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(MisRadius.full))
                                    .background(if (timerState.isRunning) Academic900 else MisSurface750)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (timerState.isRunning) "DEEP WORK" else "PAUSED",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = if (timerState.isRunning) Academic400 else MisTextMuted
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(MisSpacing.lg))

                    // Timer Physical Controls
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(MisSpacing.md),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Reset Action
                        IconButton(
                            onClick = { viewModel.resetTimer() },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MisSurface750)
                                .border(1.dp, MisBorderSubtle, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reset Timer",
                                tint = MisTextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Primary Play/Pause Instrument Button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MisRadius.md))
                                .background(Academic500)
                                .border(
                                    1.dp,
                                    Brush.verticalGradient(
                                        listOf(Color.White.copy(alpha = 0.35f), Color.Transparent)
                                    ),
                                    RoundedCornerShape(MisRadius.md)
                                )
                                .clickable { viewModel.toggleTimer() }
                                .padding(horizontal = 36.dp, vertical = 14.dp)
                                .testTag("timer_start_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (timerState.isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = MisBg950,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = if (timerState.isRunning) "Pause" else "Commence",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MisBg950
                                )
                            }
                        }

                        // Next Round Action
                        IconButton(
                            onClick = { viewModel.skipRound() },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MisSurface750)
                                .border(1.dp, MisBorderSubtle, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SkipNext,
                                contentDescription = "Next Round",
                                tint = MisTextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        // Hardware-Styled Audio & Tone Controllers (Shown only pre/post session to maintain calm during deep work)
        if (!timerState.isRunning) {
            item {
                MisCard {
                    // Section 1: Ambient Sound Generator
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Headphones,
                            contentDescription = null,
                            tint = Academic500,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "HARDWARE ACOUSTIC SYNTHESIZER",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            color = MisTextDim
                        )
                    }

                    Spacer(modifier = Modifier.height(MisSpacing.sm))

                    val soundOptions = listOf("Off", "Rain", "White Noise", "Library", "Cafe")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        soundOptions.take(4).forEach { sound ->
                            val isSelected = timerState.ambientSound == sound
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(MisRadius.sm))
                                    .background(if (isSelected) Academic900 else MisInput)
                                    .border(
                                        1.dp,
                                        if (isSelected) Academic500.copy(alpha = 0.8f) else MisBorderSubtle,
                                        RoundedCornerShape(MisRadius.sm)
                                    )
                                    .clickable { viewModel.setAmbientSound(sound) }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (isSelected) {
                                        Box(
                                            modifier = Modifier
                                                .size(5.dp)
                                                .clip(CircleShape)
                                                .background(Academic500)
                                        )
                                    }
                                    Text(
                                        text = sound,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) Academic500 else MisTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(MisSpacing.md))
                    MisDividerLine()
                    Spacer(modifier = Modifier.height(MisSpacing.md))

                    // Section 2: Brainwave Frequency Modulation
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = Academic500,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "ISOCHRONIC BRAINWAVE MODULATION",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            color = MisTextDim
                        )
                    }

                    Spacer(modifier = Modifier.height(MisSpacing.sm))

                    val tones = listOf("Off", "Alpha (10Hz)", "Beta (20Hz)", "Theta (6Hz)")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        tones.forEach { tone ->
                            val isSelected = timerState.brainwaveTone == tone
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(MisRadius.sm))
                                    .background(if (isSelected) Academic900 else MisInput)
                                    .border(
                                        1.dp,
                                        if (isSelected) Academic500.copy(alpha = 0.8f) else MisBorderSubtle,
                                        RoundedCornerShape(MisRadius.sm)
                                    )
                                    .clickable { viewModel.setBrainwaveTone(tone) }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (isSelected) {
                                        Box(
                                            modifier = Modifier
                                                .size(5.dp)
                                                .clip(CircleShape)
                                                .background(Academic400)
                                        )
                                    }
                                    Text(
                                        text = tone.takeWhile { it != ' ' },
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) Academic400 else MisTextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Daily Telemetry Budget (Surfaced pre/post session)
            item {
                MisCard {
                    Text(
                        text = "TARGET DISPATCH DEFICIT",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        color = MisTextDim
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Focus sessions automatically clear study allocations.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MisTextMuted
                    )

                    Spacer(modifier = Modifier.height(MisSpacing.md))
                    MisDividerLine()
                    Spacer(modifier = Modifier.height(MisSpacing.md))

                    val remainingStudyHours = (log.targetHours - log.hoursStudied).coerceAtLeast(0f)
                    val remainingDpps = (log.dppAssigned - log.dppCompleted).coerceAtLeast(0)
                    val uncompletedHabits = habits.count { !it.isCompletedToday }

                    Column(verticalArrangement = Arrangement.spacedBy(MisSpacing.md)) {
                        // Hours of study
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Study Deficit",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MisTextPrimary
                                )
                                Text(
                                    text = "${String.format("%.1f", remainingStudyHours)}h left",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Academic500,
                                    fontSize = 14.sp
                                )
                            }
                            ProgressRail(
                                progress = log.hoursStudied / log.targetHours,
                                fillColor = Academic500
                            )
                        }

                        // Focus rounds
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Rounds Required",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MisTextPrimary
                            )
                            Text(
                                text = "${(remainingStudyHours / 0.42f).toInt()} rounds",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Academic400,
                                fontSize = 14.sp
                            )
                        }

                        // DPPs
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "DPP Problem Sets Left",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MisTextPrimary
                            )
                            Text(
                                text = if (remainingDpps > 0) "$remainingDpps assigned" else "0 (Clear)",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (remainingDpps > 0) MisTextPrimary else Academic500,
                                fontSize = 14.sp
                            )
                        }

                        // Habits
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Habits Outstanding",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MisTextPrimary
                            )
                            Text(
                                text = "$uncompletedHabits pending",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (uncompletedHabits > 0) MisTextSecondary else Academic500,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        } else {
            // Calm Cockpit Indicator when timer is actively running
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(MisRadius.pill))
                        .background(Academic950)
                        .border(1.dp, Academic500.copy(alpha = 0.35f), RoundedCornerShape(MisRadius.pill))
                        .padding(horizontal = MisSpacing.md, vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PulseBeacon(isActive = true, color = Academic400)
                        Text(
                            text = "DEEP WORK COCKPIT ENGAGED // SURROUNDING CHROME ISOLATED",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.1.sp,
                            color = Academic400
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(MisSpacing.lg))
        }
    }
}
