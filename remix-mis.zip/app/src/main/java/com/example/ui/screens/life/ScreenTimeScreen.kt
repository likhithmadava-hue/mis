package com.example.ui.screens.life

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CircularScoreGauge
import com.example.ui.components.MisButton
import com.example.ui.components.MisCard
import com.example.ui.components.MisDividerLine
import com.example.ui.components.MisEmptyState
import com.example.ui.components.MisHeader
import com.example.ui.components.MisSectionHeader
import com.example.ui.components.ProgressRail
import com.example.ui.theme.ChartBar
import com.example.ui.theme.ChartDim
import com.example.ui.theme.ChartPrimary
import com.example.ui.theme.Danger400
import com.example.ui.theme.Danger500
import com.example.ui.theme.DangerBg
import com.example.ui.theme.DangerBorder
import com.example.ui.theme.Life300
import com.example.ui.theme.Life400
import com.example.ui.theme.Life500
import com.example.ui.theme.Life900
import com.example.ui.theme.Life950
import com.example.ui.theme.MisBg850
import com.example.ui.theme.MisBg900
import com.example.ui.theme.MisBg950
import com.example.ui.theme.MisBorder
import com.example.ui.theme.MisBorderSubtle
import com.example.ui.theme.MisDivider
import com.example.ui.theme.MisElevation
import com.example.ui.theme.MisRadius
import com.example.ui.theme.MisSpacing
import com.example.ui.theme.MisSurface700
import com.example.ui.theme.MisSurface750
import com.example.ui.theme.MisSurface800
import com.example.ui.theme.MisTextDim
import com.example.ui.theme.MisTextMuted
import com.example.ui.theme.MisTextPrimary
import com.example.ui.theme.MisTextSecondary
import com.example.ui.theme.Warning400
import com.example.ui.theme.Warning500
import com.example.ui.viewmodel.MisViewModel

@Composable
fun ScreenTimeScreen(
    viewModel: MisViewModel,
    modifier: Modifier = Modifier
) {
    val screenTimes by viewModel.screenTimes.collectAsState()
    val totalSec = screenTimes.sumOf { it.durationSeconds }
    val focusSec = screenTimes.filter { it.category == "Focus/MIS" || it.category == "Development" }.sumOf { it.durationSeconds }
    val distractionSec = screenTimes.filter { it.category == "Distraction" }.sumOf { it.durationSeconds }

    var selectedMode by remember { mutableStateOf("ALL") } // ALL, PRODUCTIVE, DISTRACTIVE
    var showGranularBreakdown by remember { mutableStateOf(false) }

    val targetGoalSec = 4 * 3600 // 4h target daily ceiling
    val focusPercentage = if (totalSec > 0) ((focusSec.toFloat() / totalSec) * 100).toInt() else 100

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = MisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(MisSpacing.md)
    ) {
        // 1. Forensic Header
        item {
            MisHeader(
                eyebrow = "DIGITAL SURVEILLANCE",
                title = "Screen Time",
                subtitle = viewModel.dateDisplayHeader,
                trailingContent = {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(MisRadius.sm))
                            .background(MisBg900)
                            .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.sm))
                            .clickable { viewModel.addSampleScreenTime() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                tint = Life500,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "SAMPLE INTEL",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Life400
                            )
                        }
                    }
                }
            )
        }

        // 2. Focal Hero: Today's Exposure vs Goal
        item {
            MisCard(isRaised = true, highlighted = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MisRadius.xs))
                                .background(Life900)
                                .border(1.dp, Life500.copy(alpha = 0.3f), RoundedCornerShape(MisRadius.xs))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "USAGE VS CEILING TELEMETRY",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = Life400
                            )
                        }
                        Spacer(modifier = Modifier.height(MisSpacing.xs))
                        Text(
                            text = if (totalSec > 0) "${totalSec / 60}m Active" else "Minimal Exposure",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MisTextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${(targetGoalSec - totalSec).coerceAtLeast(0) / 60}m remaining under 4h budget",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextDim
                        )
                    }

                    CircularScoreGauge(
                        score = focusPercentage,
                        maxScore = 100,
                        size = 84,
                        accentColor = Life500
                    )
                }

                Spacer(modifier = Modifier.height(MisSpacing.md))
                MisDividerLine()
                Spacer(modifier = Modifier.height(MisSpacing.sm))

                // Breakdown ratio rail
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Life500))
                        Text(text = "Focus (${focusSec}s)", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Life400)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Warning400))
                        Text(text = "Utility (${totalSec - focusSec - distractionSec}s)", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Warning400)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Danger500))
                        Text(text = "Distraction (${distractionSec}s)", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Danger400)
                    }
                }
            }
        }

        // 3. Application Surveillance Registry (Progressive Disclosure)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                MisSectionHeader(
                    eyebrow = "WINDOW REGISTRY",
                    title = "Active Application Dossier (${screenTimes.size})"
                )
                if (screenTimes.isNotEmpty()) {
                    MisButton(
                        text = if (showGranularBreakdown) "Collapse" else "Inspect",
                        onClick = { showGranularBreakdown = !showGranularBreakdown },
                        isPrimary = false
                    )
                }
            }
        }

        if (screenTimes.isEmpty()) {
            item {
                MisEmptyState(
                    title = "No Window Traces Recorded",
                    description = "Zero active application sessions logged in the digital telemetry buffer.",
                    categoryCode = "REGISTRY_CLEAN // 00_TRACES",
                    actionText = "Inject Sample Dossier",
                    onActionClick = { viewModel.addSampleScreenTime() }
                )
            }
        } else if (showGranularBreakdown) {
            items(screenTimes.size, key = { screenTimes[it].id }) { index ->
                val app = screenTimes[index]
                val isFocus = app.category == "Focus/MIS" || app.category == "Development"
                val isDistraction = app.category == "Distraction"

                val categoryColor = when {
                    isFocus -> Life500
                    isDistraction -> Danger500
                    else -> MisTextDim
                }

                MisCard(isRaised = false) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(MisRadius.xs))
                                        .background(if (isFocus) Life900 else MisSurface750),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isFocus) Icons.Default.Terminal else Icons.Default.PhoneAndroid,
                                        contentDescription = null,
                                        tint = categoryColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = app.appName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontFamily = FontFamily.Monospace,
                                        color = MisTextPrimary
                                    )
                                    Text(
                                        text = app.category.uppercase(),
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = categoryColor
                                    )
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "${app.durationSeconds}s",
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MisTextSecondary
                                )
                                Text(
                                    text = "${app.percentage}%",
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isFocus) Life400 else MisTextPrimary
                                )
                            }
                        }

                        // Exposure bar
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(MisSurface750)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth((app.percentage / 100f).coerceIn(0.02f, 1f))
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(categoryColor)
                            )
                        }
                    }
                }
            }
        } else if (!showGranularBreakdown) {
            item {
                MisCard(isRaised = false) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showGranularBreakdown = true }
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${screenTimes.size} application sessions active in memory buffer",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextSecondary
                        )
                        Text(
                            text = "Tap to inspect traces",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Life400
                        )
                    }
                }
            }
        }

        // 4. End to End Day Chronology
        item {
            MisCard(isRaised = false) {
                Text(
                    text = "CHRONOLOGY TIMELINE",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = MisTextDim
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Continuous Session Span",
                    style = MaterialTheme.typography.titleMedium,
                    color = MisTextPrimary
                )
                Spacer(modifier = Modifier.height(MisSpacing.sm))

                // Timeline Strip
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(18.dp)
                        .clip(RoundedCornerShape(MisRadius.xs))
                        .background(MisSurface750)
                ) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        Spacer(modifier = Modifier.weight(0.35f))
                        Box(
                            modifier = Modifier
                                .weight(0.25f)
                                .fillMaxSize()
                                .background(Life500)
                        )
                        Spacer(modifier = Modifier.weight(0.4f))
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "08:00 (Start)", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = MisTextDim)
                    Text(text = "14:00 (Peak)", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Life400)
                    Text(text = "22:00 (Rest)", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = MisTextDim)
                }
            }
        }

        // 5. 7-Day Exposure Trend
        item {
            MisCard(isRaised = false) {
                Text(
                    text = "7-DAY EXPOSURE TREND",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = MisTextDim
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Daily Screen Allocation",
                    style = MaterialTheme.typography.titleMedium,
                    color = MisTextPrimary
                )
                Spacer(modifier = Modifier.height(MisSpacing.md))

                val dates = listOf("09-02", "09-03", "09-04", "09-05", "09-06", "09-07", "09-08")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    dates.forEachIndexed { index, date ->
                        val isToday = index == 6
                        val barHeight = if (isToday) 80.dp else if (index == 5) 50.dp else 24.dp

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(16.dp)
                                    .height(barHeight)
                                    .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                    .background(if (isToday) Life500 else MisSurface750)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = date.takeLast(2),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (isToday) Life400 else MisTextDim
                            )
                        }
                    }
                }
            }
        }

        // 6. Privacy & Trust Protocol
        item {
            MisCard(isRaised = false) {
                Row(
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(MisSpacing.sm)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Zero-Cloud Privacy",
                        tint = Life500,
                        modifier = Modifier.size(20.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Zero-Cloud Encryption Vault",
                            style = MaterialTheme.typography.titleSmall,
                            color = MisTextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Screen time is captured purely while MIS is active, held exclusively in your local SQLite Room database, and never synced to third-party telemetry.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextDim,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(MisSpacing.md))

                        Row(horizontalArrangement = Arrangement.spacedBy(MisSpacing.sm)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(MisRadius.sm))
                                    .background(MisSurface750)
                                    .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.sm))
                                    .clickable { viewModel.forgetThisDay() }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                    .testTag("forget_day_button")
                            ) {
                                Text(
                                    text = "PURGE TODAY",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MisTextSecondary
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(MisRadius.sm))
                                    .background(DangerBg)
                                    .border(1.dp, DangerBorder, RoundedCornerShape(MisRadius.sm))
                                    .clickable { viewModel.forgetEverything() }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                    .testTag("forget_everything_button")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = null,
                                        tint = Danger400,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = "PURGE ALL",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = Danger400
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(MisSpacing.lg))
        }
    }
}
