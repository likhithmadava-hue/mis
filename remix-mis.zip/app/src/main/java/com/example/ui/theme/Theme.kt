package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

enum class MisWorkspace {
    ACADEMIC,
    LIFE
}

data class MisThemeColors(
    val accentPrimary: Color,
    val accentHover: Color,
    val accentDark: Color,
    val accentDarkSurface: Color,
    val accentGlow: Color,
    val workspace: MisWorkspace
)

val LocalMisTheme = staticCompositionLocalOf {
    MisThemeColors(
        accentPrimary = Academic500,
        accentHover = Academic400,
        accentDark = Academic600,
        accentDarkSurface = Academic900,
        accentGlow = Academic500.copy(alpha = 0.15f),
        workspace = MisWorkspace.ACADEMIC
    )
}

fun getMisColorScheme(workspace: MisWorkspace) = darkColorScheme(
    primary = if (workspace == MisWorkspace.ACADEMIC) Academic500 else Life500,
    onPrimary = MisBg950,
    primaryContainer = if (workspace == MisWorkspace.ACADEMIC) Academic900 else Life900,
    onPrimaryContainer = if (workspace == MisWorkspace.ACADEMIC) Academic300 else Life300,
    secondary = MisTextSecondary,
    onSecondary = MisBg950,
    background = MisBg950,
    onBackground = MisTextPrimary,
    surface = MisSurface800,
    onSurface = MisTextPrimary,
    surfaceVariant = MisSurface750,
    onSurfaceVariant = MisTextSecondary,
    outline = MisBorder,
    outlineVariant = MisBorderSubtle,
    error = Danger500,
    onError = MisTextPrimary,
    errorContainer = DangerBg,
    onErrorContainer = Danger400
)

@Composable
fun MisAppTheme(
    workspace: MisWorkspace = MisWorkspace.ACADEMIC,
    content: @Composable () -> Unit
) {
    val colorScheme = getMisColorScheme(workspace)

    val misColors = if (workspace == MisWorkspace.ACADEMIC) {
        MisThemeColors(
            accentPrimary = Academic500,
            accentHover = Academic400,
            accentDark = Academic600,
            accentDarkSurface = Academic900,
            accentGlow = Academic500.copy(alpha = 0.15f),
            workspace = MisWorkspace.ACADEMIC
        )
    } else {
        MisThemeColors(
            accentPrimary = Life500,
            accentHover = Life400,
            accentDark = Life600,
            accentDarkSurface = Life900,
            accentGlow = Life500.copy(alpha = 0.15f),
            workspace = MisWorkspace.LIFE
        )
    }

    CompositionLocalProvider(LocalMisTheme provides misColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
