package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.draw.scale
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Priority
import com.example.ui.theme.Academic400
import com.example.ui.theme.Academic500
import com.example.ui.theme.Academic900
import com.example.ui.theme.Danger400
import com.example.ui.theme.Danger500
import com.example.ui.theme.DangerBg
import com.example.ui.theme.DangerBorder
import com.example.ui.theme.Life400
import com.example.ui.theme.Life500
import com.example.ui.theme.Life900
import com.example.ui.theme.LocalMisTheme
import com.example.ui.theme.MisBg850
import com.example.ui.theme.MisBg900
import com.example.ui.theme.MisBg950
import com.example.ui.theme.MisBorder
import com.example.ui.theme.MisBorderStrong
import com.example.ui.theme.MisBorderSubtle
import com.example.ui.theme.MisDivider
import com.example.ui.theme.MisElevation
import com.example.ui.theme.MisIconSize
import com.example.ui.theme.MisInput
import com.example.ui.theme.MisRadius
import com.example.ui.theme.MisSpacing
import com.example.ui.theme.MisSurface700
import com.example.ui.theme.MisSurface750
import com.example.ui.theme.MisSurface800
import com.example.ui.theme.MisTextDim
import com.example.ui.theme.MisTextDisabled
import com.example.ui.theme.MisTextMuted
import com.example.ui.theme.MisTextPrimary
import com.example.ui.theme.MisTextSecondary
import com.example.ui.theme.MisWorkspace
import com.example.ui.theme.Warning400
import com.example.ui.theme.Warning500
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MisHeader(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    eyebrow: String? = null,
    trailingContent: (@Composable () -> Unit)? = null
) {
    val accent = LocalMisTheme.current.accentPrimary

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = MisSpacing.sm),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f, fill = false)) {
            if (eyebrow != null) {
                Text(
                    text = eyebrow.uppercase(),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.4.sp,
                    color = accent,
                    modifier = Modifier.padding(start = 11.dp, bottom = 2.dp)
                )
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Subtle glowing accent bar
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .height(24.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(accent, accent.copy(alpha = 0.3f))
                            )
                        )
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.displayMedium,
                    color = MisTextPrimary
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MisTextDim,
                modifier = Modifier.padding(start = 11.dp)
            )
        }
        if (trailingContent != null) {
            trailingContent()
        }
    }
}

@Composable
fun PulseBeacon(
    isActive: Boolean = true,
    color: Color = LocalMisTheme.current.accentPrimary,
    modifier: Modifier = Modifier,
    size: Int = 8
) {
    if (!isActive) {
        Box(
            modifier = modifier.size((size * 2).dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size((size * 2).dp)) {
                drawCircle(
                    color = color.copy(alpha = 0.25f),
                    radius = size.dp.toPx() / 2.2f
                )
            }
        }
        return
    }

    val infiniteTransition = rememberInfiniteTransition(label = "beacon")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 2.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "beacon_scale"
    )
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "beacon_alpha"
    )

    Box(
        modifier = modifier.size((size * 2).dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size((size * 2).dp)) {
            // Expanding ring
            drawCircle(
                color = color.copy(alpha = alpha),
                radius = (size.dp.toPx() / 2f) * scale
            )
            // Solid center
            drawCircle(
                color = color,
                radius = size.dp.toPx() / 2.2f
            )
        }
    }
}

@Composable
fun ModeSwitcher(
    currentWorkspace: MisWorkspace,
    onWorkspaceChanged: (MisWorkspace) -> Unit,
    modifier: Modifier = Modifier
) {
    val isAcademic = currentWorkspace == MisWorkspace.ACADEMIC
    val activeAccent = if (isAcademic) Academic500 else Life500

    val animatedBorderColor by animateColorAsState(
        targetValue = activeAccent.copy(alpha = 0.6f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "mode_border"
    )

    // Hero-Level Segmented Control with Specular Highlight and Tactile Pill
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(MisRadius.pill))
            .background(MisBg900)
            .border(
                BorderStroke(
                    1.dp,
                    Brush.horizontalGradient(
                        listOf(
                            animatedBorderColor,
                            MisBorderSubtle,
                            animatedBorderColor
                        )
                    )
                ),
                RoundedCornerShape(MisRadius.pill)
            )
            .padding(3.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            // Academic Segment
            val academicBg by animateColorAsState(
                targetValue = if (isAcademic) Academic500 else Color.Transparent,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "acad_bg"
            )
            val academicText by animateColorAsState(
                targetValue = if (isAcademic) MisBg950 else MisTextMuted,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "acad_txt"
            )

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(MisRadius.pill))
                    .background(academicBg)
                    .clickable { onWorkspaceChanged(MisWorkspace.ACADEMIC) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .testTag("mode_academic_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = "Academic Workspace",
                    tint = academicText,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "ACADEMIC",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    color = academicText
                )
            }

            // Life Segment
            val lifeBg by animateColorAsState(
                targetValue = if (!isAcademic) Life500 else Color.Transparent,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "life_bg"
            )
            val lifeText by animateColorAsState(
                targetValue = if (!isAcademic) MisBg950 else MisTextMuted,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "life_txt"
            )

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(MisRadius.pill))
                    .background(lifeBg)
                    .clickable { onWorkspaceChanged(MisWorkspace.LIFE) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .testTag("mode_life_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Eco,
                    contentDescription = "Life Workspace",
                    tint = lifeText,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "LIFE",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    color = lifeText
                )
            }
        }
    }
}

@Composable
fun PrioritySelector(
    selectedPriority: String,
    onPrioritySelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(MisRadius.md))
            .background(MisBg900)
            .border(BorderStroke(1.dp, MisBorderSubtle), RoundedCornerShape(MisRadius.md))
            .padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        listOf(
            Triple("H", "◆ HIGH", Danger400),
            Triple("M", "■ MED", Warning400),
            Triple("L", "● LOW", MisTextSecondary)
        ).forEach { (code, label, activeColor) ->
            val isSelected = selectedPriority.equals(code, ignoreCase = true)
            val bgColor = when {
                isSelected && code == "H" -> DangerBg
                isSelected && code == "M" -> MisSurface750
                isSelected -> MisSurface800
                else -> Color.Transparent
            }
            val borderColor = when {
                isSelected && code == "H" -> DangerBorder
                isSelected && code == "M" -> Warning500.copy(alpha = 0.4f)
                isSelected -> MisBorder
                else -> Color.Transparent
            }
            val textColor = if (isSelected) activeColor else MisTextDim

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(MisRadius.sm))
                    .background(bgColor)
                    .border(BorderStroke(1.dp, borderColor), RoundedCornerShape(MisRadius.sm))
                    .clickable { onPrioritySelected(code) }
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    letterSpacing = 0.5.sp,
                    color = textColor
                )
            }
        }
    }
}

@Composable
fun PriorityBadge(
    priority: String,
    modifier: Modifier = Modifier
) {
    val upper = priority.uppercase()
    val (label, bgColor, textColor, borderColor) = when (upper) {
        "HIGH", "H" -> Quadruple("◆ HIGH", DangerBg, Danger400, DangerBorder)
        "MEDIUM", "MED", "M" -> Quadruple("■ MED", MisBg900, Warning400, Warning500.copy(alpha = 0.35f))
        else -> Quadruple("● LOW", MisBg900, MisTextMuted, MisBorderSubtle)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(MisRadius.xs))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(MisRadius.xs))
            .padding(horizontal = 7.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp,
            color = textColor
        )
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
fun ScoreCapsule(
    scoreText: String,
    modifier: Modifier = Modifier,
    accentColor: Color = LocalMisTheme.current.accentPrimary
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(MisRadius.sm))
            .background(MisBg900)
            .border(
                BorderStroke(
                    1.dp,
                    Brush.horizontalGradient(
                        listOf(accentColor.copy(alpha = 0.5f), MisBorder)
                    )
                ),
                RoundedCornerShape(MisRadius.sm)
            )
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = scoreText,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            color = accentColor
        )
    }
}

@Composable
fun CircularScoreGauge(
    score: Int,
    maxScore: Int = 50,
    modifier: Modifier = Modifier,
    size: Int = 80,
    accentColor: Color = LocalMisTheme.current.accentPrimary
) {
    val progress = (score.toFloat() / maxScore.toFloat()).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "score_arc"
    )

    Box(
        modifier = modifier.size(size.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size.dp)) {
            val strokeWidth = 7.dp.toPx()
            val diameter = this.size.minDimension - strokeWidth
            val topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f)
            val arcSize = Size(diameter, diameter)

            // Background arc (280 degrees total)
            drawArc(
                color = MisSurface700,
                startAngle = 130f,
                sweepAngle = 280f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Active progress arc with sweep gradient
            if (animatedProgress > 0f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            accentColor.copy(alpha = 0.5f),
                            accentColor,
                            accentColor
                        )
                    ),
                    startAngle = 130f,
                    sweepAngle = 280f * animatedProgress,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )

                // Leading glowing indicator dot
                val currentAngle = (130f + 280f * animatedProgress) * (Math.PI / 180f)
                val center = Offset(this.size.width / 2f, this.size.height / 2f)
                val radius = diameter / 2f
                val dotCenter = Offset(
                    (center.x + radius * cos(currentAngle)).toFloat(),
                    (center.y + radius * sin(currentAngle)).toFloat()
                )

                drawCircle(
                    color = accentColor.copy(alpha = 0.4f),
                    radius = strokeWidth * 0.9f,
                    center = dotCenter
                )
                drawCircle(
                    color = Color.White,
                    radius = strokeWidth * 0.4f,
                    center = dotCenter
                )
            }
        }

        // Numerical score in center
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = if (score > 0) "$score" else "—",
                fontSize = 22.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = if (score > 0) accentColor else MisTextDim
            )
            Text(
                text = "/ $maxScore",
                fontSize = 10.sp,
                color = MisTextMuted,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun ProgressRail(
    progress: Float,
    modifier: Modifier = Modifier,
    fillColor: Color = LocalMisTheme.current.accentPrimary,
    trackColor: Color = MisDivider,
    height: Int = 6
) {
    val clampedProgress = progress.coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = clampedProgress,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "rail_progress"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height.dp)
            .clip(RoundedCornerShape(height.dp))
            .background(trackColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(animatedProgress)
                .height(height.dp)
                .clip(RoundedCornerShape(height.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(fillColor.copy(alpha = 0.75f), fillColor)
                    )
                )
        )
    }
}

@Composable
fun MisCard(
    modifier: Modifier = Modifier,
    isRaised: Boolean = false,
    highlighted: Boolean = false,
    isFeatured: Boolean = false,
    content: @Composable () -> Unit
) {
    val misTheme = LocalMisTheme.current
    val bgColor = when {
        isFeatured -> MisSurface750
        isRaised -> MisSurface750
        else -> MisSurface800
    }
    val borderColor = when {
        isFeatured -> misTheme.accentPrimary.copy(alpha = 0.45f)
        highlighted -> misTheme.accentPrimary.copy(alpha = 0.4f)
        isRaised -> MisBorder
        else -> MisBorderSubtle
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .drawBehind {
                // Specular highlight along the top edge for crisp optical depth
                val highlightAlpha = when {
                    isFeatured -> 0.18f
                    highlighted -> 0.12f
                    else -> 0.05f
                }
                val highlightBrush = Brush.horizontalGradient(
                    listOf(
                        Color.Transparent,
                        Color.White.copy(alpha = highlightAlpha),
                        Color.Transparent
                    )
                )
                drawLine(
                    brush = highlightBrush,
                    start = Offset(16.dp.toPx(), 1f),
                    end = Offset(size.width - 16.dp.toPx(), 1f),
                    strokeWidth = if (isFeatured) 2f else 1.5f
                )
            }
            .border(BorderStroke(1.dp, borderColor), RoundedCornerShape(MisRadius.xl)),
        shape = RoundedCornerShape(MisRadius.xl),
        color = bgColor,
        tonalElevation = if (isFeatured) MisElevation.level3 else if (isRaised) MisElevation.level2 else MisElevation.level1
    ) {
        Column(modifier = Modifier.padding(MisSpacing.lg)) {
            content()
        }
    }
}

@Composable
fun MisDividerLine(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(MisDivider)
    )
}

@Composable
fun MisCheckbox(
    checked: Boolean,
    onCheckedChange: () -> Unit,
    modifier: Modifier = Modifier,
    accentColor: Color = LocalMisTheme.current.accentPrimary
) {
    val animatedBg by animateColorAsState(
        targetValue = if (checked) accentColor else MisBg900,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "chk_bg"
    )
    val animatedBorder by animateColorAsState(
        targetValue = if (checked) accentColor else MisBorderStrong,
        label = "chk_brd"
    )

    Box(
        modifier = modifier
            .size(24.dp)
            .clip(RoundedCornerShape(MisRadius.sm))
            .background(animatedBg)
            .border(1.5.dp, animatedBorder, RoundedCornerShape(MisRadius.sm))
            .clickable(onClick = onCheckedChange),
        contentAlignment = Alignment.Center
    ) {
        if (checked) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "Completed",
                tint = MisBg950,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun MisButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isPrimary: Boolean = true,
    isDestructive: Boolean = false,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    icon: ImageVector? = null
) {
    val misTheme = LocalMisTheme.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "btn_scale"
    )

    val (bgColor, textColor, borderColor) = when {
        !enabled -> Triple(MisBg900, MisTextDisabled, MisBorderSubtle)
        isDestructive -> Triple(DangerBg, Danger400, DangerBorder)
        isPrimary -> Triple(misTheme.accentPrimary, MisBg950, Color.Transparent)
        else -> Triple(MisSurface750, MisTextSecondary, MisBorder)
    }

    Row(
        modifier = modifier
            .scale(scale)
            .clip(RoundedCornerShape(MisRadius.md))
            .background(bgColor)
            .border(BorderStroke(1.dp, borderColor), RoundedCornerShape(MisRadius.md))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled && !isLoading,
                onClick = onClick
            )
            .padding(horizontal = MisSpacing.md, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(16.dp).padding(end = 6.dp),
                color = textColor,
                strokeWidth = 2.dp
            )
        } else if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier
                    .size(16.dp)
                    .padding(end = 4.dp)
            )
        }
        Text(
            text = text,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = textColor
        )
    }
}

@Composable
fun MisSectionHeader(
    eyebrow: String,
    title: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null
) {
    val accent = LocalMisTheme.current.accentPrimary

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = MisSpacing.lg, bottom = MisSpacing.xs),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = eyebrow.uppercase(),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.4.sp,
                color = accent
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = MisTextPrimary
            )
        }
        trailing?.invoke()
    }
}

@Composable
fun MisFilterChip(
    label: String,
    isSelected: Boolean,
    onSelected: () -> Unit,
    modifier: Modifier = Modifier,
    count: Int? = null,
    accentColor: Color = LocalMisTheme.current.accentPrimary
) {
    val bgColor = if (isSelected) accentColor.copy(alpha = 0.15f) else MisBg900
    val borderColor = if (isSelected) accentColor else MisBorderSubtle
    val textColor = if (isSelected) accentColor else MisTextSecondary

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(MisRadius.pill))
            .background(bgColor)
            .border(BorderStroke(1.dp, borderColor), RoundedCornerShape(MisRadius.pill))
            .clickable(onClick = onSelected)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            letterSpacing = 0.6.sp,
            color = textColor
        )
        if (count != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(MisRadius.xs))
                    .background(if (isSelected) accentColor.copy(alpha = 0.25f) else MisSurface750)
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
                Text(
                    text = "$count",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = textColor
                )
            }
        }
    }
}

@Composable
fun MisEmptyState(
    title: String,
    description: String,
    modifier: Modifier = Modifier,
    categoryCode: String = "NO_RECORDS_FOUND",
    actionText: String? = null,
    onActionClick: (() -> Unit)? = null
) {
    val accent = LocalMisTheme.current.accentPrimary

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(MisRadius.xl))
            .background(MisSurface800)
            .border(BorderStroke(1.dp, MisBorderSubtle), RoundedCornerShape(MisRadius.xl))
            .padding(MisSpacing.xxl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(MisBg900)
                .border(1.dp, MisBorder, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Inbox,
                contentDescription = null,
                tint = MisTextDim,
                modifier = Modifier.size(24.dp)
            )
        }

        Spacer(modifier = Modifier.height(MisSpacing.md))

        Text(
            text = categoryCode,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            color = accent
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MisTextPrimary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium,
            color = MisTextDim,
            textAlign = TextAlign.Center
        )

        if (actionText != null && onActionClick != null) {
            Spacer(modifier = Modifier.height(MisSpacing.lg))
            MisButton(
                text = actionText,
                onClick = onActionClick,
                isPrimary = false
            )
        }
    }
}

@Composable
fun MisSaveConfirmation(
    visible: Boolean,
    message: String = "DAILY LOG COMMITTED",
    modifier: Modifier = Modifier
) {
    val accent = LocalMisTheme.current.accentPrimary

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(200)) + slideInVertically(tween(300)) { it / 2 },
        exit = fadeOut(tween(200)) + slideOutVertically(tween(300)) { it / 2 },
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(MisRadius.pill))
                .background(MisBg900)
                .border(BorderStroke(1.dp, accent.copy(alpha = 0.6f)), RoundedCornerShape(MisRadius.pill))
                .padding(horizontal = MisSpacing.md, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = message,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = MisTextPrimary
                )
            }
        }
    }
}

/**
 * Transient alert toast for runtime intelligence notifications or errors.
 */
@Composable
fun MisToast(
    visible: Boolean,
    message: String,
    modifier: Modifier = Modifier,
    isWarning: Boolean = false
) {
    val accent = if (isWarning) Danger400 else LocalMisTheme.current.accentPrimary

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(150)) + slideInVertically(tween(250)) { -it / 2 },
        exit = fadeOut(tween(150)) + slideOutVertically(tween(250)) { -it / 2 },
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(MisRadius.pill))
                .background(MisBg900)
                .border(BorderStroke(1.dp, accent.copy(alpha = 0.7f)), RoundedCornerShape(MisRadius.pill))
                .padding(horizontal = MisSpacing.md, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = if (isWarning) Icons.Default.Warning else Icons.Default.Info,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = message,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    color = MisTextPrimary
                )
            }
        }
    }
}

/**
 * Shimmering skeleton loader for content hydration states.
 */
@Composable
fun MisSkeletonLoader(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = RoundedCornerShape(MisRadius.md)
) {
    val infiniteTransition = rememberInfiniteTransition(label = "skeleton_shimmer")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "skeleton_alpha"
    )

    Box(
        modifier = modifier
            .clip(shape)
            .background(MisSurface750.copy(alpha = alpha))
            .border(BorderStroke(1.dp, MisBorderSubtle.copy(alpha = alpha)), shape)
    )
}


