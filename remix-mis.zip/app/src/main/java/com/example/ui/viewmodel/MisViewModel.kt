package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.error.GlobalErrorHandler
import com.example.data.api.SyncTelemetryPayload
import com.example.data.db.AppDatabase
import com.example.data.model.AcademicLogEntity
import com.example.data.model.AppScreenTimeEntity
import com.example.data.model.HabitEntity
import com.example.data.model.LifeLogEntity
import com.example.data.model.MistakeEntity
import com.example.data.model.TodoItemEntity
import com.example.data.repository.MisRemoteRepository
import com.example.data.repository.MisRepository
import com.example.ui.theme.MisWorkspace
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MisDestination(val title: String, val academicOnly: Boolean = false, val lifeOnly: Boolean = false) {
    HOME("Home"),
    DAILY_LOG("Daily Log"),
    REPORT("Report"),
    DATABASE("Database", academicOnly = true),
    FOCUS_TIMER("Focus Timer", academicOnly = true),
    SCREEN_TIME("Screen Time", lifeOnly = true)
}

data class TimerUiState(
    val secondsRemaining: Int = 25 * 60,
    val initialSeconds: Int = 25 * 60,
    val isRunning: Boolean = false,
    val currentRound: Int = 1,
    val totalRoundsCompleted: Int = 0,
    val ambientSound: String = "Off",
    val brainwaveTone: String = "Off"
)

data class DatabaseFilterState(
    val searchQuery: String = "",
    val subject: String = "All subjects",
    val chapter: String = "All chapters",
    val errorType: String = "All errors",
    val difficulty: String = "Any difficulty"
)

data class ReportFilterState(
    val range: String = "7D", // 7D, 14D, 30D
    val view: String = "Overview"
)

class MisViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = MisRepository(database)
    private val remoteRepository = MisRemoteRepository()
    private val exceptionHandler = GlobalErrorHandler.coroutineExceptionHandler("MisViewModel")

    val todayDate = "2026-09-08"
    val dateDisplayHeader = "Good evening — Tuesday, September 8"

    private val _workspace = MutableStateFlow(MisWorkspace.ACADEMIC)
    val workspace: StateFlow<MisWorkspace> = _workspace.asStateFlow()

    private val _currentDestination = MutableStateFlow(MisDestination.HOME)
    val currentDestination: StateFlow<MisDestination> = _currentDestination.asStateFlow()

    // Timer State
    private val _timerState = MutableStateFlow(TimerUiState())
    val timerState: StateFlow<TimerUiState> = _timerState.asStateFlow()
    private var timerJob: Job? = null

    // Database Filters
    private val _databaseFilters = MutableStateFlow(DatabaseFilterState())
    val databaseFilters: StateFlow<DatabaseFilterState> = _databaseFilters.asStateFlow()

    // Report Filters
    private val _reportFilters = MutableStateFlow(ReportFilterState())
    val reportFilters: StateFlow<ReportFilterState> = _reportFilters.asStateFlow()

    // Data Flows
    val academicLog: StateFlow<AcademicLogEntity?> = repository.getAcademicLog(todayDate)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val lifeLog: StateFlow<LifeLogEntity?> = repository.getLifeLog(todayDate)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allHabits: StateFlow<List<HabitEntity>> = repository.getAllHabits()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val academicTodos: StateFlow<List<TodoItemEntity>> = repository.getTodos("ACADEMIC")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lifeTodos: StateFlow<List<TodoItemEntity>> = repository.getTodos("LIFE")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMistakes: StateFlow<List<MistakeEntity>> = repository.getAllMistakes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val screenTimes: StateFlow<List<AppScreenTimeEntity>> = repository.getScreenTimes(todayDate)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAcademicLogs: StateFlow<List<AcademicLogEntity>> = repository.getAllAcademicLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLifeLogs: StateFlow<List<LifeLogEntity>> = repository.getAllLifeLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Quotes
    val academicQuotes = listOf(
        Pair("Strive for progress, not perfection.", "UNKNOWN"),
        Pair("Study the way you solve.", "MIS PRINCIPLE"),
        Pair("Mistakes are the portal of discovery.", "JAMES JOYCE"),
        Pair("The work that moves your marks.", "MIS ACADEMIC")
    )
    private val _currentQuoteIndex = MutableStateFlow(0)
    val currentQuote: StateFlow<Pair<String, String>> = combine(_currentQuoteIndex) { indices ->
        academicQuotes[indices[0] % academicQuotes.size]
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), academicQuotes[0])

    fun nextQuote() {
        _currentQuoteIndex.value = (_currentQuoteIndex.value + 1) % academicQuotes.size
    }

    /**
     * Attempts to fetch a daily directive from the online cloud API.
     * On network/API failure, GlobalErrorHandler will automatically display an error Snackbar with RETRY.
     */
    fun fetchOnlineQuote() {
        viewModelScope.launch(exceptionHandler) {
            val result = remoteRepository.fetchDailyQuote(retryCallback = { fetchOnlineQuote() })
            result.onSuccess { quote ->
                // Successfully fetched online quote
                nextQuote()
            }
        }
    }

    /**
     * Synchronizes today's telemetry with the remote MIS intelligence server.
     * Handled by GlobalErrorHandler with automatic Snackbar alert on fault.
     */
    fun syncCloudTelemetry() {
        viewModelScope.launch(exceptionHandler) {
            val academic = academicLog.value
            val payload = SyncTelemetryPayload(
                date = todayDate,
                academicScore = academic?.calculatedScore ?: 0,
                hoursStudied = academic?.hoursStudied ?: 0f,
                totalAnomalies = allMistakes.value.size
            )
            remoteRepository.syncTelemetry(payload, retryCallback = { syncCloudTelemetry() })
        }
    }

    /**
     * Test trigger to verify that API call errors are caught globally and notified via Snackbar.
     */
    fun testTriggerApiError(simulateOffline: Boolean = false) {
        viewModelScope.launch(exceptionHandler) {
            if (simulateOffline) {
                remoteRepository.simulateNetworkError(retryCallback = { testTriggerApiError(true) })
            } else {
                remoteRepository.simulateApiError(errorCode = 503, retryCallback = { testTriggerApiError(false) })
            }
        }
    }

    /**
     * Test trigger to verify that Database operational errors are caught globally and notified via Snackbar.
     */
    fun testTriggerDbError() {
        viewModelScope.launch(exceptionHandler) {
            repository.simulateDatabaseError(retryAction = { testTriggerDbError() })
        }
    }

    // Workspace & Navigation
    fun switchWorkspace(newWorkspace: MisWorkspace) {
        _workspace.value = newWorkspace
        // If current destination is invalid for the new workspace, fallback to HOME
        val current = _currentDestination.value
        if (newWorkspace == MisWorkspace.ACADEMIC && current.lifeOnly) {
            _currentDestination.value = MisDestination.HOME
        } else if (newWorkspace == MisWorkspace.LIFE && current.academicOnly) {
            _currentDestination.value = MisDestination.HOME
        }
    }

    fun navigateTo(destination: MisDestination) {
        _currentDestination.value = destination
    }

    // Academic Log Actions
    fun updateStudiesHours(hours: Float) {
        val current = academicLog.value ?: AcademicLogEntity(date = todayDate)
        val updated = current.copy(hoursStudied = hours.coerceIn(0f, 12f))
        recalculateAndSaveAcademic(updated)
    }

    fun updateTargetHours(target: Float) {
        val current = academicLog.value ?: AcademicLogEntity(date = todayDate)
        val updated = current.copy(targetHours = target.coerceIn(1f, 16f))
        recalculateAndSaveAcademic(updated)
    }

    fun updateStudiesPriority(priority: String) {
        val current = academicLog.value ?: AcademicLogEntity(date = todayDate)
        val updated = current.copy(studiesPriority = priority)
        recalculateAndSaveAcademic(updated)
    }

    fun updateDppAssigned(assigned: Int) {
        val current = academicLog.value ?: AcademicLogEntity(date = todayDate)
        val updated = current.copy(dppAssigned = assigned.coerceAtLeast(1))
        recalculateAndSaveAcademic(updated)
    }

    fun updateDppCompleted(completed: Int) {
        val current = academicLog.value ?: AcademicLogEntity(date = todayDate)
        val updated = current.copy(dppCompleted = completed.coerceAtLeast(0))
        recalculateAndSaveAcademic(updated)
    }

    fun updateDppPriority(priority: String) {
        val current = academicLog.value ?: AcademicLogEntity(date = todayDate)
        val updated = current.copy(dppPriority = priority)
        recalculateAndSaveAcademic(updated)
    }

    fun updateAcademicTasksPriority(priority: String) {
        val current = academicLog.value ?: AcademicLogEntity(date = todayDate)
        val updated = current.copy(tasksPriority = priority)
        recalculateAndSaveAcademic(updated)
    }

    fun saveAcademicLog() {
        val current = academicLog.value ?: AcademicLogEntity(date = todayDate)
        recalculateAndSaveAcademic(current)
    }

    private fun recalculateAndSaveAcademic(entity: AcademicLogEntity) {
        viewModelScope.launch(exceptionHandler) {
            val todos = academicTodos.value
            val completed = todos.count { it.isCompleted }
            val score = MisRepository.calculateAcademicScore(entity, completed, todos.size)
            repository.saveAcademicLog(entity.copy(calculatedScore = score), retryAction = {
                recalculateAndSaveAcademic(entity)
            })
        }
    }

    fun saveLifeLog() {
        val current = lifeLog.value ?: LifeLogEntity(date = todayDate)
        recalculateAndSaveLife(current)
    }

    // Life Log Actions
    fun updateMoodScore(score: Int) {
        val current = lifeLog.value ?: LifeLogEntity(date = todayDate)
        val updated = current.copy(moodScore = score.coerceIn(0, 10))
        recalculateAndSaveLife(updated)
    }

    fun updateMoodPriority(priority: String) {
        val current = lifeLog.value ?: LifeLogEntity(date = todayDate)
        val updated = current.copy(moodPriority = priority)
        recalculateAndSaveLife(updated)
    }

    fun updateLeisureMinutes(minutes: Int) {
        val current = lifeLog.value ?: LifeLogEntity(date = todayDate)
        val updated = current.copy(leisureMinutes = minutes.coerceIn(0, 240))
        recalculateAndSaveLife(updated)
    }

    fun updateWellSpentPriority(priority: String) {
        val current = lifeLog.value ?: LifeLogEntity(date = todayDate)
        val updated = current.copy(wellSpentPriority = priority)
        recalculateAndSaveLife(updated)
    }

    fun updateHabitsPriority(priority: String) {
        val current = lifeLog.value ?: LifeLogEntity(date = todayDate)
        val updated = current.copy(habitsPriority = priority)
        recalculateAndSaveLife(updated)
    }

    fun updateLifeTasksPriority(priority: String) {
        val current = lifeLog.value ?: LifeLogEntity(date = todayDate)
        val updated = current.copy(tasksPriority = priority)
        recalculateAndSaveLife(updated)
    }

    fun incrementHydration() {
        val current = lifeLog.value ?: LifeLogEntity(date = todayDate)
        val updated = current.copy(hydrationCups = (current.hydrationCups + 1).coerceAtMost(current.maxHydration))
        recalculateAndSaveLife(updated)
    }

    fun decrementHydration() {
        val current = lifeLog.value ?: LifeLogEntity(date = todayDate)
        val updated = current.copy(hydrationCups = (current.hydrationCups - 1).coerceAtLeast(0))
        recalculateAndSaveLife(updated)
    }

    fun incrementPosture() {
        val current = lifeLog.value ?: LifeLogEntity(date = todayDate)
        val updated = current.copy(postureChecks = (current.postureChecks + 1).coerceAtMost(current.maxPosture))
        recalculateAndSaveLife(updated)
    }

    fun updateSleepWindow(bed: String, wake: String) {
        val current = lifeLog.value ?: LifeLogEntity(date = todayDate)
        val updated = current.copy(bedtime = bed, wakeTime = wake)
        recalculateAndSaveLife(updated)
    }

    private fun recalculateAndSaveLife(entity: LifeLogEntity) {
        viewModelScope.launch(exceptionHandler) {
            val habits = allHabits.value
            val completedHabits = habits.count { it.isCompletedToday }
            val todos = lifeTodos.value
            val completedTodos = todos.count { it.isCompleted }
            val score = MisRepository.calculateLifeScore(
                entity,
                completedHabits,
                habits.size,
                completedTodos,
                todos.size
            )
            repository.saveLifeLog(entity.copy(calculatedScore = score), retryAction = {
                recalculateAndSaveLife(entity)
            })
        }
    }

    // Habits Actions
    fun addHabit(title: String, priority: String = "MEDIUM") {
        if (title.isBlank()) return
        viewModelScope.launch(exceptionHandler) {
            repository.addHabit(title.trim(), priority, retryAction = { addHabit(title, priority) })
            lifeLog.value?.let { recalculateAndSaveLife(it) }
        }
    }

    fun toggleHabit(id: Long, currentCompleted: Boolean) {
        viewModelScope.launch(exceptionHandler) {
            repository.toggleHabit(id, !currentCompleted, retryAction = { toggleHabit(id, currentCompleted) })
            lifeLog.value?.let { recalculateAndSaveLife(it) }
        }
    }

    fun updateHabitPriority(id: Long, priority: String) {
        viewModelScope.launch(exceptionHandler) {
            repository.updateHabitPriority(id, priority, retryAction = { updateHabitPriority(id, priority) })
        }
    }

    fun deleteHabit(id: Long) {
        viewModelScope.launch(exceptionHandler) {
            repository.deleteHabit(id, retryAction = { deleteHabit(id) })
            lifeLog.value?.let { recalculateAndSaveLife(it) }
        }
    }

    // Todos Actions
    fun addTodo(title: String, subjectTag: String, dueDate: String, workspace: String) {
        if (title.isBlank()) return
        viewModelScope.launch(exceptionHandler) {
            repository.addTodo(title.trim(), subjectTag.trim(), dueDate.trim(), workspace, retryAction = {
                addTodo(title, subjectTag, dueDate, workspace)
            })
            if (workspace == "ACADEMIC") {
                academicLog.value?.let { recalculateAndSaveAcademic(it) }
            } else {
                lifeLog.value?.let { recalculateAndSaveLife(it) }
            }
        }
    }

    fun toggleTodo(id: Long, currentCompleted: Boolean, workspace: String) {
        viewModelScope.launch(exceptionHandler) {
            repository.toggleTodo(id, !currentCompleted, retryAction = {
                toggleTodo(id, currentCompleted, workspace)
            })
            if (workspace == "ACADEMIC") {
                academicLog.value?.let { recalculateAndSaveAcademic(it) }
            } else {
                lifeLog.value?.let { recalculateAndSaveLife(it) }
            }
        }
    }

    fun deleteTodo(id: Long, workspace: String) {
        viewModelScope.launch(exceptionHandler) {
            repository.deleteTodo(id, retryAction = {
                deleteTodo(id, workspace)
            })
            if (workspace == "ACADEMIC") {
                academicLog.value?.let { recalculateAndSaveAcademic(it) }
            } else {
                lifeLog.value?.let { recalculateAndSaveLife(it) }
            }
        }
    }

    // Mistakes Actions
    fun addMistake(
        title: String,
        subject: String,
        chapter: String,
        errorType: String,
        difficulty: String,
        marksLost: Int,
        notes: String
    ) {
        viewModelScope.launch(exceptionHandler) {
            val entity = MistakeEntity(
                title = title.trim(),
                subject = subject,
                chapter = chapter.trim(),
                errorType = errorType,
                difficulty = difficulty,
                marksLost = marksLost,
                notes = notes.trim(),
                dateAdded = todayDate
            )
            repository.addMistake(entity, retryAction = {
                addMistake(title, subject, chapter, errorType, difficulty, marksLost, notes)
            })
        }
    }

    fun updateMistake(mistake: MistakeEntity) {
        viewModelScope.launch(exceptionHandler) {
            repository.updateMistake(mistake, retryAction = { updateMistake(mistake) })
        }
    }

    fun deleteMistake(id: Long) {
        viewModelScope.launch(exceptionHandler) {
            repository.deleteMistake(id, retryAction = { deleteMistake(id) })
        }
    }

    fun deleteAllMistakes() {
        viewModelScope.launch(exceptionHandler) {
            repository.deleteAllMistakes(retryAction = { deleteAllMistakes() })
        }
    }

    fun importSampleMistakes() {
        viewModelScope.launch(exceptionHandler) {
            val samples = listOf(
                MistakeEntity(
                    title = "Electromagnetic Induction flux integration sign error",
                    subject = "Physics",
                    chapter = "EMI & AC",
                    errorType = "Calculation",
                    difficulty = "Medium",
                    marksLost = 4,
                    notes = "Forgot Lenz's law negative sign during dot product evaluation with angled B field.",
                    dateAdded = todayDate
                ),
                MistakeEntity(
                    title = "Carbocation rearrangement in Pinacol coupling",
                    subject = "Chemistry",
                    chapter = "Organic Chemistry II",
                    errorType = "Conceptual",
                    difficulty = "Hard",
                    marksLost = 3,
                    notes = "Overlooked hydride vs methyl shift migratory aptitude in acidic media.",
                    dateAdded = todayDate
                ),
                MistakeEntity(
                    title = "Definite Integral limits substitution error",
                    subject = "Math",
                    chapter = "Definite Integrals",
                    errorType = "Silly mistake",
                    difficulty = "Easy",
                    marksLost = 2,
                    notes = "Substituted t limits without modifying upper boundary from pi/2 to 1.",
                    dateAdded = todayDate
                )
            )
            samples.forEach { repository.addMistake(it) }
        }
    }

    fun updateDatabaseSearch(query: String) {
        _databaseFilters.value = _databaseFilters.value.copy(searchQuery = query)
    }

    fun updateDatabaseSubject(subject: String) {
        _databaseFilters.value = _databaseFilters.value.copy(subject = subject)
    }

    fun updateDatabaseChapter(chapter: String) {
        _databaseFilters.value = _databaseFilters.value.copy(chapter = chapter)
    }

    fun updateDatabaseErrorType(errorType: String) {
        _databaseFilters.value = _databaseFilters.value.copy(errorType = errorType)
    }

    fun updateDatabaseDifficulty(difficulty: String) {
        _databaseFilters.value = _databaseFilters.value.copy(difficulty = difficulty)
    }

    // Report Filter Actions
    fun updateReportRange(range: String) {
        _reportFilters.value = _reportFilters.value.copy(range = range)
    }

    fun updateReportView(view: String) {
        _reportFilters.value = _reportFilters.value.copy(view = view)
    }

    // Focus Timer Actions
    fun toggleTimer() {
        if (_timerState.value.isRunning) {
            pauseTimer()
        } else {
            startTimer()
        }
    }

    fun startTimer() {
        timerJob?.cancel()
        _timerState.value = _timerState.value.copy(isRunning = true)
        timerJob = viewModelScope.launch {
            while (_timerState.value.secondsRemaining > 0 && _timerState.value.isRunning) {
                delay(1000)
                _timerState.value = _timerState.value.copy(
                    secondsRemaining = _timerState.value.secondsRemaining - 1
                )
            }
            if (_timerState.value.secondsRemaining <= 0) {
                skipRound()
            }
        }
    }

    fun pauseTimer() {
        timerJob?.cancel()
        _timerState.value = _timerState.value.copy(isRunning = false)
    }

    fun resetTimer() {
        timerJob?.cancel()
        _timerState.value = _timerState.value.copy(
            secondsRemaining = _timerState.value.initialSeconds,
            isRunning = false
        )
    }

    fun skipRound() {
        timerJob?.cancel()
        val nextRound = _timerState.value.currentRound + 1
        val completed = _timerState.value.totalRoundsCompleted + 1
        _timerState.value = _timerState.value.copy(
            secondsRemaining = _timerState.value.initialSeconds,
            isRunning = false,
            currentRound = nextRound,
            totalRoundsCompleted = completed
        )
        // Add 25 mins (0.42h) to studied hours
        val currentHours = academicLog.value?.hoursStudied ?: 0f
        updateStudiesHours((currentHours + 0.42f).coerceAtMost(12f))
    }

    fun setAmbientSound(sound: String) {
        _timerState.value = _timerState.value.copy(ambientSound = sound)
    }

    fun setBrainwaveTone(tone: String) {
        _timerState.value = _timerState.value.copy(brainwaveTone = tone)
    }

    // Screen Time Actions
    fun forgetThisDay() {
        viewModelScope.launch(exceptionHandler) {
            repository.deleteScreenTimeForDate(todayDate, retryAction = { forgetThisDay() })
        }
    }

    fun forgetEverything() {
        viewModelScope.launch(exceptionHandler) {
            repository.deleteAllScreenTime(retryAction = { forgetEverything() })
        }
    }

    fun addSampleScreenTime() {
        viewModelScope.launch(exceptionHandler) {
            repository.addScreenTimeApp("mis.exe", 45, 60, "Focus/MIS", todayDate)
            repository.addScreenTimeApp("snippingtool.exe", 30, 40, "Utility", todayDate)
        }
    }

    fun setWorkspace(newWorkspace: MisWorkspace) {
        switchWorkspace(newWorkspace)
    }

    class Factory(private val app: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MisViewModel(app) as T
        }
    }
}
