package com.example.ui.screens.life

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LifeLogEntity
import com.example.ui.components.CircularScoreGauge
import com.example.ui.components.MisCard
import com.example.ui.components.MisDividerLine
import com.example.ui.components.MisHeader
import com.example.ui.components.MisSectionHeader
import com.example.ui.components.ProgressRail
import com.example.ui.components.PulseBeacon
import com.example.ui.theme.Danger500
import com.example.ui.theme.Life300
import com.example.ui.theme.Life400
import com.example.ui.theme.Life500
import com.example.ui.theme.Life800
import com.example.ui.theme.Life900
import com.example.ui.theme.Life950
import com.example.ui.theme.MisBg850
import com.example.ui.theme.MisBg900
import com.example.ui.theme.MisBg950
import com.example.ui.theme.MisBorder
import com.example.ui.theme.MisBorderSubtle
import com.example.ui.theme.MisElevation
import com.example.ui.theme.MisRadius
import com.example.ui.theme.MisSpacing
import com.example.ui.theme.MisSurface750
import com.example.ui.theme.MisSurface800
import com.example.ui.theme.MisTextDim
import com.example.ui.theme.MisTextMuted
import com.example.ui.theme.MisTextPrimary
import com.example.ui.theme.MisTextSecondary
import com.example.ui.theme.Warning400
import com.example.ui.theme.Warning500
import com.example.ui.viewmodel.MisDestination
import com.example.ui.viewmodel.MisViewModel

@Composable
fun LifeHomeScreen(
    viewModel: MisViewModel,
    modifier: Modifier = Modifier
) {
    val lifeLog by viewModel.lifeLog.collectAsState()
    val habits by viewModel.allHabits.collectAsState()
    val todos by viewModel.lifeTodos.collectAsState()
    val screenTimes by viewModel.screenTimes.collectAsState()
    val log = lifeLog ?: LifeLogEntity(date = viewModel.todayDate)

    val completedHabits = habits.count { it.isCompletedToday }
    val totalHabits = habits.size
    val firstOutstandingHabit = habits.firstOrNull { !it.isCompletedToday }
    val hasLoggedToday = log.calculatedScore > 0 || log.hydrationCups > 0 || log.postureChecks > 0

    // Biometric mood description
    val moodDescriptor = when (log.moodScore) {
        in 9..10 -> "PEAK FLOW"
        in 7..8 -> "GROUNDED"
        in 5..6 -> "BALANCED"
        in 3..4 -> "FATIGUED"
        else -> "DEPLETED"
    }

    val moodColor = when (log.moodScore) {
        in 7..10 -> Life400
        in 5..6 -> Warning400
        else -> Danger500
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = MisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(MisSpacing.md)
    ) {
        // 1. Briefing Header
        item {
            MisHeader(
                eyebrow = "LIFE INTELLIGENCE",
                title = "Harmony",
                subtitle = viewModel.dateDisplayHeader,
                trailingContent = {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(MisRadius.sm))
                            .background(MisBg900)
                            .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.sm))
                            .clickable { viewModel.navigateTo(MisDestination.DAILY_LOG) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.EditNote,
                                contentDescription = null,
                                tint = Life500,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (hasLoggedToday) "EDIT LOG" else "LOG TODAY",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Life400
                            )
                        }
                    }
                }
            )
        }

        // 2. Biometric Index Featured Card
        item {
            MisCard(isRaised = true, highlighted = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(MisSpacing.xs)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(MisRadius.xs))
                                    .background(Life900)
                                    .border(1.dp, Life500.copy(alpha = 0.3f), RoundedCornerShape(MisRadius.xs))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "BIOMETRIC HARMONY",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = Life400
                                )
                            }
                            PulseBeacon(isActive = hasLoggedToday, color = Life500, size = 6)
                        }

                        Spacer(modifier = Modifier.height(MisSpacing.xs))

                        Text(
                            text = if (log.calculatedScore >= 40) "Optimal State" else if (log.calculatedScore >= 25) "Stable Baseline" else "Calibration Incomplete",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MisTextPrimary
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Habit momentum, circadian rhythm, and cognitive replenishment index",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextDim
                        )
                    }

                    CircularScoreGauge(
                        score = log.calculatedScore,
                        maxScore = 50,
                        size = 88,
                        accentColor = Life500
                    )
                }

                Spacer(modifier = Modifier.height(MisSpacing.md))
                ProgressRail(
                    progress = (log.calculatedScore / 50f).coerceIn(0f, 1f),
                    fillColor = Life500,
                    height = 6
                )
            }
        }

        // 3. Prominent Habit Protocol
        item {
            MisCard(isRaised = true, highlighted = firstOutstandingHabit != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(MisSpacing.xs)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(MisRadius.xs))
                                    .background(if (firstOutstandingHabit != null) Life900 else MisSurface750)
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (firstOutstandingHabit != null) "NEXT DISCIPLINE" else "DISCIPLINES CLEAR",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = if (firstOutstandingHabit != null) Life400 else MisTextDim
                                )
                            }
                            if (firstOutstandingHabit != null) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocalFireDepartment,
                                        contentDescription = "Streak",
                                        tint = Warning500,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "${firstOutstandingHabit.streak}d streak",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = Warning400
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(MisSpacing.xs))

                        Text(
                            text = firstOutstandingHabit?.title ?: "All behavioral routines verified",
                            style = MaterialTheme.typography.titleLarge,
                            color = MisTextPrimary
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        val pct = if (totalHabits > 0) (completedHabits * 100) / totalHabits else 100
                        Text(
                            text = "$completedHabits of $totalHabits executed · $pct% protocol completion",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextDim
                        )
                    }

                    if (firstOutstandingHabit != null) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MisRadius.md))
                                .background(Life500)
                                .clickable { viewModel.toggleHabit(firstOutstandingHabit.id, false) }
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                                .testTag("tick_habit_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = MisBg950,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Execute",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MisBg950
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(MisSpacing.sm))
                ProgressRail(
                    progress = if (totalHabits > 0) completedHabits.toFloat() / totalHabits else 1f,
                    fillColor = Life500
                )
            }
        }

        // 4. Biometric HUD Telemetry (The 4 Core Vectors)
        item {
            MisSectionHeader(
                eyebrow = "TELEMETRY MATRIX",
                title = "Current Vitals"
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(MisSpacing.xs)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(MisSpacing.xs)
                ) {
                    // Habits Vector
                    MisCard(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "HABITS",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = MisTextDim
                            )
                            Icon(
                                imageVector = Icons.Default.Spa,
                                contentDescription = null,
                                tint = Life500,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(MisSpacing.xs))
                        Text(
                            text = "$completedHabits / $totalHabits",
                            fontSize = 22.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Life400
                        )
                        Text(
                            text = "routines logged",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextMuted
                        )
                    }

                    // Mood Vector
                    MisCard(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "MOOD STATE",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = MisTextDim
                            )
                            Icon(
                                imageVector = Icons.Default.Mood,
                                contentDescription = null,
                                tint = moodColor,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(MisSpacing.xs))
                        Text(
                            text = moodDescriptor,
                            fontSize = 16.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = moodColor
                        )
                        Text(
                            text = "${log.moodScore}/10 intensity",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextMuted
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(MisSpacing.xs)
                ) {
                    // Well-Spent Leisure Vector
                    MisCard(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "WELL-SPENT",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = MisTextDim
                            )
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = Warning500,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(MisSpacing.xs))
                        Text(
                            text = "${log.leisureMinutes}m",
                            fontSize = 22.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Warning400
                        )
                        Text(
                            text = "intentional replenishment",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextMuted
                        )
                    }

                    // Tasks Vector
                    val completedTasks = todos.count { it.isCompleted }
                    MisCard(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "LIFE TASKS",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = MisTextDim
                            )
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = MisTextPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(MisSpacing.xs))
                        Text(
                            text = "$completedTasks / ${todos.size}",
                            fontSize = 22.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = MisTextPrimary
                        )
                        Text(
                            text = "to-dos fulfilled",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextMuted
                        )
                    }
                }
            }
        }

        // 5. Wellness & Circadian Protocol
        item {
            MisCard(isRaised = false) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "BIOLOGICAL PROTOCOLS",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = MisTextDim
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Hydration & Posture Cadence",
                            style = MaterialTheme.typography.titleMedium,
                            color = MisTextPrimary
                        )
                    }

                    // Quick increment actions
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Hydration +
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MisRadius.sm))
                                .background(Life900)
                                .border(1.dp, Life500.copy(alpha = 0.3f), RoundedCornerShape(MisRadius.sm))
                                .clickable { viewModel.incrementHydration() }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WaterDrop,
                                    contentDescription = null,
                                    tint = Life400,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "+1 Cup",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Life300
                                )
                            }
                        }

                        // Posture +
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MisRadius.sm))
                                .background(MisSurface750)
                                .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.sm))
                                .clickable { viewModel.incrementPosture() }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SelfImprovement,
                                    contentDescription = null,
                                    tint = MisTextPrimary,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "+ Check",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MisTextPrimary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(MisSpacing.md))
                MisDividerLine()
                Spacer(modifier = Modifier.height(MisSpacing.md))

                // Protocol telemetry gauges
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(MisSpacing.md)
                ) {
                    // Hydration Progress
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "HYDRATION",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MisTextDim
                            )
                            Text(
                                text = "${log.hydrationCups}/${log.maxHydration}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Life400
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        ProgressRail(
                            progress = (log.hydrationCups.toFloat() / log.maxHydration.coerceAtLeast(1)).coerceIn(0f, 1f),
                            fillColor = Life500
                        )
                    }

                    // Posture Checks Progress
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "ERGONOMICS",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MisTextDim
                            )
                            Text(
                                text = "${log.postureChecks}/${log.maxPosture}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = MisTextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        ProgressRail(
                            progress = (log.postureChecks.toFloat() / log.maxPosture.coerceAtLeast(1)).coerceIn(0f, 1f),
                            fillColor = MisTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(MisSpacing.md))

                // Sleep Arc window
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(MisRadius.sm))
                        .background(MisBg950)
                        .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.sm))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Nightlight,
                            contentDescription = "Circadian Arc",
                            tint = Life400,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Circadian Window",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MisTextPrimary
                        )
                    }
                    Text(
                        text = "${log.bedtime} → ${log.wakeTime}",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Life400
                    )
                }
            }
        }

        // 6. Digital Surveillance Hook
        item {
            val totalSec = screenTimes.sumOf { it.durationSeconds }
            val topApp = screenTimes.maxByOrNull { it.durationSeconds }?.appName ?: "mis.app"

            MisCard(isRaised = false) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhoneAndroid,
                                contentDescription = null,
                                tint = MisTextDim,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "SCREEN TIME INTELLIGENCE",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = MisTextDim
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (totalSec > 0) "${totalSec / 60}m tracked today" else "Minimal digital footprint",
                            style = MaterialTheme.typography.titleMedium,
                            color = MisTextPrimary
                        )
                        Text(
                            text = "Primary vector: $topApp",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextMuted
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(MisRadius.sm))
                            .background(MisSurface750)
                            .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.sm))
                            .clickable { viewModel.navigateTo(MisDestination.SCREEN_TIME) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "DOSSIER",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Life400
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = null,
                                tint = Life400,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(MisSpacing.lg))
        }
    }
}
