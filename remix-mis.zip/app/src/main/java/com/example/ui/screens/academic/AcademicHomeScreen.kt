package com.example.ui.screens.academic

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AcademicLogEntity
import com.example.ui.components.CircularScoreGauge
import com.example.ui.components.MisButton
import com.example.ui.components.MisCard
import com.example.ui.components.MisHeader
import com.example.ui.components.MisSectionHeader
import com.example.ui.components.PriorityBadge
import com.example.ui.components.ProgressRail
import com.example.ui.theme.Academic400
import com.example.ui.theme.Academic500
import com.example.ui.theme.Academic900
import com.example.ui.theme.Danger400
import com.example.ui.theme.MisBg850
import com.example.ui.theme.MisBg900
import com.example.ui.theme.MisBorder
import com.example.ui.theme.MisBorderSubtle
import com.example.ui.theme.MisRadius
import com.example.ui.theme.MisSpacing
import com.example.ui.theme.MisSurface700
import com.example.ui.theme.MisSurface750
import com.example.ui.theme.MisSurface800
import com.example.ui.theme.MisTextDim
import com.example.ui.theme.MisTextMuted
import com.example.ui.theme.MisTextPrimary
import com.example.ui.theme.MisTextSecondary
import com.example.ui.viewmodel.MisDestination
import com.example.ui.viewmodel.MisViewModel

@Composable
fun AcademicHomeScreen(
    viewModel: MisViewModel,
    modifier: Modifier = Modifier
) {
    val academicLog by viewModel.academicLog.collectAsState()
    val allLogs by viewModel.allAcademicLogs.collectAsState()
    val quote by viewModel.currentQuote.collectAsState()
    val todos by viewModel.academicTodos.collectAsState()
    val mistakeEntries by viewModel.allMistakes.collectAsState()
    val log = academicLog ?: AcademicLogEntity(date = viewModel.todayDate)

    val hasLoggedToday = log.calculatedScore > 0 || log.hoursStudied > 0f

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = MisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(MisSpacing.md)
    ) {
        // 1. Briefing Header
        item {
            MisHeader(
                eyebrow = "ACADEMIC INTELLIGENCE",
                title = "Dashboard",
                subtitle = viewModel.dateDisplayHeader,
                trailingContent = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Cloud Sync Telemetry Button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MisRadius.sm))
                                .background(MisBg900)
                                .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.sm))
                                .clickable { viewModel.syncCloudTelemetry() }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("academic_cloud_sync_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sync,
                                    contentDescription = "Sync Cloud Telemetry",
                                    tint = Academic500,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "SYNC",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.8.sp,
                                    color = Academic500
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MisRadius.sm))
                                .background(MisBg900)
                                .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.sm))
                                .clickable { viewModel.navigateTo(MisDestination.DAILY_LOG) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.EditNote,
                                    contentDescription = null,
                                    tint = Academic500,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "LOG TODAY",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.8.sp,
                                    color = Academic500
                                )
                            }
                        }
                    }
                }
            )
        }

        // 2. Focal Hero Element: Today's Academic Score
        item {
            MisCard(isFeatured = true, highlighted = hasLoggedToday) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(MisRadius.xs))
                                    .background(Academic900)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (hasLoggedToday) "CALCULATED INDEX" else "AWAITING LOG",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = if (hasLoggedToday) Academic400 else MisTextDim
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(MisSpacing.xs))

                        Text(
                            text = "Academic Score",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MisTextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (hasLoggedToday)
                                "Composite index across deep study, task output & DPP completion"
                            else
                                "Commit today's study round and assignments to calculate index",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (hasLoggedToday) Academic400 else MisTextDim
                        )
                    }

                    // World-Class Circular Gauge
                    CircularScoreGauge(
                        score = log.calculatedScore,
                        maxScore = 50,
                        size = 88,
                        accentColor = Academic500
                    )
                }

                Spacer(modifier = Modifier.height(MisSpacing.lg))
                ProgressRail(
                    progress = if (hasLoggedToday) log.calculatedScore / 50f else 0f,
                    fillColor = Academic500,
                    height = 6
                )

                // Micro metrics breakdown tags
                Spacer(modifier = Modifier.height(MisSpacing.md))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "STUDY",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            color = MisTextMuted
                        )
                        Text(
                            text = "${String.format("%.1f", log.hoursStudied)}h / ${log.targetHours.toInt()}h",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (log.hoursStudied >= log.targetHours) Academic400 else MisTextSecondary
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "TASKS",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            color = MisTextMuted
                        )
                        val completedCount = todos.count { it.isCompleted }
                        Text(
                            text = "$completedCount / ${todos.size}",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = MisTextSecondary
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "DPPS",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            color = MisTextMuted
                        )
                        Text(
                            text = "${log.dppCompleted} / ${log.dppAssigned}",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = MisTextSecondary
                        )
                    }
                }
            }
        }

        // 3. Fast Action Strip: Focus Engine
        item {
            MisCard(isRaised = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(MisSpacing.md),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(MisRadius.md))
                                .background(Academic900),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = Academic500,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "Focus Timer",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MisTextPrimary
                            )
                            Text(
                                text = "Target: ${log.targetHours.toInt()}h deep study session",
                                style = MaterialTheme.typography.bodySmall,
                                color = MisTextDim
                            )
                        }
                    }

                    MisButton(
                        text = "Start",
                        onClick = { viewModel.navigateTo(MisDestination.FOCUS_TIMER) },
                        icon = Icons.Default.PlayArrow,
                        modifier = Modifier.testTag("start_focus_home_button")
                    )
                }
            }
        }

        // 4. Secondary Intelligence: 2x2 Scannable Metric Tiles
        item {
            MisSectionHeader(
                eyebrow = "TELEMETRY",
                title = "Study Analytics"
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(MisSpacing.sm)
            ) {
                // Study Streak
                MisCard(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "STUDY STREAK",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = MisTextDim
                    )
                    Spacer(modifier = Modifier.height(MisSpacing.xs))
                    Text(
                        text = if (log.hoursStudied > 0f) "1" else "0",
                        fontSize = 24.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = MisTextPrimary
                    )
                    Text(
                        text = "active days logged",
                        style = MaterialTheme.typography.bodySmall,
                        color = MisTextMuted
                    )

                    Spacer(modifier = Modifier.height(MisSpacing.xs))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        repeat(7) { index ->
                            val isActive = index == 6 && log.hoursStudied > 0f
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (isActive) Academic500 else MisSurface750)
                            )
                        }
                    }
                }

                // 7-Day Average
                MisCard(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "7-DAY AVERAGE",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = MisTextDim
                    )
                    Spacer(modifier = Modifier.height(MisSpacing.xs))
                    val avg = if (allLogs.isNotEmpty()) {
                        allLogs.map { it.calculatedScore }.average().toInt()
                    } else log.calculatedScore
                    Text(
                        text = "$avg",
                        fontSize = 24.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = MisTextPrimary
                    )
                    Text(
                        text = "out of 50 target",
                        style = MaterialTheme.typography.bodySmall,
                        color = MisTextMuted
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(MisSpacing.sm)
            ) {
                // Hours Logged
                MisCard(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "TODAY'S HOURS",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = MisTextDim
                    )
                    Spacer(modifier = Modifier.height(MisSpacing.xs))
                    Text(
                        text = "${String.format("%.1f", log.hoursStudied)}h",
                        fontSize = 24.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Academic500
                    )
                    Text(
                        text = "target ${log.targetHours.toInt()}h",
                        style = MaterialTheme.typography.bodySmall,
                        color = MisTextMuted
                    )
                }

                // Deep Work Ratio
                MisCard(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "DEEP WORK",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = MisTextDim
                    )
                    Spacer(modifier = Modifier.height(MisSpacing.xs))
                    Text(
                        text = "${if (log.targetHours > 0f) ((log.hoursStudied / log.targetHours) * 100).toInt().coerceAtMost(100) else 0}%",
                        fontSize = 24.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Academic400
                    )
                    Text(
                        text = "focus target completion",
                        style = MaterialTheme.typography.bodySmall,
                        color = MisTextMuted
                    )
                }
            }
        }

        // 5. Recent Mistake Intel (if any recorded)
        if (mistakeEntries.isNotEmpty()) {
            item {
                MisSectionHeader(
                    eyebrow = "MISTAKE SURVEILLANCE",
                    title = "Recent Diagnostic Entries",
                    trailing = {
                        Text(
                            text = "VIEW ALL",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Academic500,
                            modifier = Modifier.clickable { viewModel.navigateTo(MisDestination.DATABASE) }
                        )
                    }
                )
            }

            items(mistakeEntries.take(3), key = { it.id }) { mistake ->
                MisCard(isRaised = false) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = mistake.subject.uppercase(),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = Academic400
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Academic900)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = mistake.errorType,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = MisTextDim
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = mistake.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = MisTextPrimary
                            )
                            if (mistake.notes.isNotBlank()) {
                                Text(
                                    text = mistake.notes,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MisTextDim,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // 6. Directive Quote Card
        item {
            MisCard(isRaised = false) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(MisSpacing.sm),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(MisRadius.sm))
                                .background(Academic900),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FormatQuote,
                                contentDescription = null,
                                tint = Academic500,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "“${quote.first}”",
                                style = MaterialTheme.typography.bodyLarge,
                                fontStyle = FontStyle.Italic,
                                color = MisTextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = quote.second,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Academic400
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { viewModel.fetchOnlineQuote() },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("fetch_online_quote_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Sync,
                                contentDescription = "Fetch Online Directive",
                                tint = Academic400,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        IconButton(
                            onClick = { viewModel.nextQuote() },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("next_quote_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Next Directive",
                                tint = MisTextDim,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(MisSpacing.xxl))
        }
    }
}

