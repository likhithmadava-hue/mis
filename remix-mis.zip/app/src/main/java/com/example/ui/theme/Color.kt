package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Base Dark Foundation
val MisBg950 = Color(0xFF061117)
val MisBg900 = Color(0xFF08151C)
val MisBg850 = Color(0xFF0A1820)
val MisSurface800 = Color(0xFF0C1C24)
val MisSurface750 = Color(0xFF10232C)
val MisSurface700 = Color(0xFF132A34)
val MisInput = Color(0xFF07141A)
val MisSidebar = Color(0xFF07131A)

// Borders
val MisBorderSubtle = Color(0xFF142A33)
val MisBorder = Color(0xFF1A343E)
val MisBorderStrong = Color(0xFF23434D)
val MisDivider = Color(0xFF183039)

// Typography (Certified WCAG AA compliant on all Mis dark surfaces)
val MisTextPrimary = Color(0xFFF0F5F6)     // High emphasis headline / display text (15.8:1)
val MisTextSecondary = Color(0xFFBDCCD2)   // Body and UI labels (10.2:1)
val MisTextMuted = Color(0xFF98ACB6)       // Secondary metadata / subtitles (6.8:1)
val MisTextDim = Color(0xFF8298A2)         // Eyebrows, mono tags, disabled labels (4.8:1, passes AA)
val MisTextFaint = Color(0xFF6A818C)       // Gridlines, inactive tick marks (3.5:1, graphical UI elements)
val MisTextDisabled = Color(0xFF4A5E67)    // Disabled state indicators

// Academic Cyan System
val Academic300 = Color(0xFF73E0F8)
val Academic400 = Color(0xFF47D5F6)
val Academic500 = Color(0xFF20C7F2)
val Academic600 = Color(0xFF0CAFD9)
val Academic700 = Color(0xFF0782A3)
val Academic800 = Color(0xFF0B3C48)
val Academic850 = Color(0xFF08303B)
val Academic900 = Color(0xFF06252E)
val Academic950 = Color(0xFF041A21)
val AcademicHover = Color(0xFF3CD1F5)
val AcademicPressed = Color(0xFF0BA3CA)

// Life Emerald System
val Life300 = Color(0xFF7CECC0)
val Life400 = Color(0xFF4BE3A5)
val Life500 = Color(0xFF20D78B)
val Life600 = Color(0xFF10BF79)
val Life700 = Color(0xFF0B905B)
val Life800 = Color(0xFF0B4736)
val Life850 = Color(0xFF08382B)
val Life900 = Color(0xFF062A21)
val Life950 = Color(0xFF041B14)
val LifeHover = Color(0xFF38E09A)
val LifePressed = Color(0xFF0DAF6E)

// Semantic
val Warning500 = Color(0xFFE7B84B)
val Warning400 = Color(0xFFF0C963)
val WarningBg = Color(0xFF2A230F)
val WarningBorder = Color(0xFF5A481B)

val Danger500 = Color(0xFFF05E66)
val Danger400 = Color(0xFFF67A80)
val DangerBg = Color(0xFF2A1115)
val DangerBorder = Color(0xFF5A2429)

// Charts
val ChartPrimary = Color(0xFFA9BAC1)
val ChartSecondary = Color(0xFF748990)
val ChartGrid = Color(0xFF183039)
val ChartBar = Color(0xFF6F858D)
val ChartDim = Color(0xFF435961)
