package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarData
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.Danger400
import com.example.ui.theme.Danger500
import com.example.ui.theme.DangerBg
import com.example.ui.theme.DangerBorder
import com.example.ui.theme.MisBg900
import com.example.ui.theme.MisBg950
import com.example.ui.theme.MisBorderStrong
import com.example.ui.theme.MisRadius
import com.example.ui.theme.MisSpacing
import com.example.ui.theme.MisTextDim
import com.example.ui.theme.MisTextPrimary
import com.example.ui.theme.MisTextSecondary

/**
 * Custom MIS-themed high-contrast error and alert Snackbar.
 * Displays domain-specific API / Database operational faults with optional retry action.
 */
@Composable
fun MisErrorSnackbar(
    snackbarData: SnackbarData,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = MisSpacing.md, vertical = 6.dp)
            .testTag("global_mis_snackbar"),
        shape = RoundedCornerShape(MisRadius.md),
        color = MisBg900,
        shadowElevation = 8.dp,
        border = BorderStroke(1.dp, DangerBorder)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    // Top edge alert line highlight
                    val glowBrush = Brush.horizontalGradient(
                        listOf(
                            Danger500.copy(alpha = 0.8f),
                            Danger400,
                            Danger500.copy(alpha = 0.2f)
                        )
                    )
                    drawLine(
                        brush = glowBrush,
                        start = Offset(0f, 0f),
                        end = Offset(size.width, 0f),
                        strokeWidth = 3f
                    )
                }
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Leading Anomaly Icon & Status Badge
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(MisRadius.sm))
                        .background(DangerBg)
                        .border(1.dp, DangerBorder, RoundedCornerShape(MisRadius.sm)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Anomaly Alert",
                        tint = Danger400,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Error Message & Classification
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "SYSTEM EXCEPTION //",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = Danger400
                        )
                        PulseBeacon(color = Danger500, size = 6)
                    }

                    Text(
                        text = snackbarData.visuals.message,
                        style = MaterialTheme.typography.bodySmall,
                        color = MisTextPrimary,
                        maxLines = 3,
                        modifier = Modifier.testTag("snackbar_message_text")
                    )
                }

                // Optional Action Button (e.g. "RETRY" or "DISMISS")
                snackbarData.visuals.actionLabel?.let { actionLabel ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(MisRadius.xs))
                            .background(DangerBg)
                            .border(1.dp, Danger400.copy(alpha = 0.6f), RoundedCornerShape(MisRadius.xs))
                            .clickable { snackbarData.performAction() }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("snackbar_action_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = actionLabel.uppercase(),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            color = Danger400
                        )
                    }
                }

                // Dismiss icon
                IconButton(
                    onClick = { snackbarData.dismiss() },
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("snackbar_dismiss_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss error notification",
                        tint = MisTextDim,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
