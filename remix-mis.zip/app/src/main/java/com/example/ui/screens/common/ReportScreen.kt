package com.example.ui.screens.common

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CircularScoreGauge
import com.example.ui.components.MisCard
import com.example.ui.components.MisDividerLine
import com.example.ui.components.MisHeader
import com.example.ui.components.MisSectionHeader
import com.example.ui.components.ProgressRail
import com.example.ui.theme.Academic400
import com.example.ui.theme.Academic500
import com.example.ui.theme.ChartBar
import com.example.ui.theme.ChartDim
import com.example.ui.theme.ChartGrid
import com.example.ui.theme.Life400
import com.example.ui.theme.Life500
import com.example.ui.theme.LocalMisTheme
import com.example.ui.theme.MisBg850
import com.example.ui.theme.MisBg900
import com.example.ui.theme.MisBg950
import com.example.ui.theme.MisBorder
import com.example.ui.theme.MisBorderSubtle
import com.example.ui.theme.MisElevation
import com.example.ui.theme.MisRadius
import com.example.ui.theme.MisSpacing
import com.example.ui.theme.MisSurface700
import com.example.ui.theme.MisSurface750
import com.example.ui.theme.MisSurface800
import com.example.ui.theme.MisTextDim
import com.example.ui.theme.MisTextMuted
import com.example.ui.theme.MisTextPrimary
import com.example.ui.theme.MisTextSecondary
import com.example.ui.theme.MisWorkspace
import com.example.ui.theme.Warning400
import com.example.ui.theme.Warning500
import com.example.ui.viewmodel.MisViewModel

@Composable
fun ReportScreen(
    viewModel: MisViewModel,
    modifier: Modifier = Modifier
) {
    val workspace by viewModel.workspace.collectAsState()
    val filters by viewModel.reportFilters.collectAsState()
    val academicLog by viewModel.academicLog.collectAsState()
    val lifeLog by viewModel.lifeLog.collectAsState()
    val allAcademicLogs by viewModel.allAcademicLogs.collectAsState()
    val allLifeLogs by viewModel.allLifeLogs.collectAsState()

    val accentColor = LocalMisTheme.current.accentPrimary
    val isAcademic = workspace == MisWorkspace.ACADEMIC

    val avgScore = if (isAcademic) {
        if (allAcademicLogs.isNotEmpty()) allAcademicLogs.map { it.calculatedScore }.average().toInt()
        else academicLog?.calculatedScore ?: 0
    } else {
        if (allLifeLogs.isNotEmpty()) allLifeLogs.map { it.calculatedScore }.average().toInt()
        else lifeLog?.calculatedScore ?: 0
    }

    val totalHoursLogged = academicLog?.hoursStudied ?: 0f

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = MisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(MisSpacing.md)
    ) {
        // 1. Executive Intelligence Header
        item {
            MisHeader(
                eyebrow = if (isAcademic) "ACADEMIC INTELLIGENCE" else "LIFE BIOMETRICS",
                title = "Executive Report",
                subtitle = viewModel.dateDisplayHeader
            )
        }

        // 2. Control Range Strip & Aggregate Metric
        item {
            MisCard(isRaised = true, highlighted = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Segmented range pills
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(MisRadius.sm))
                            .background(MisBg950)
                            .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.sm))
                            .padding(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf("7D", "14D", "30D").forEach { r ->
                            val isSelected = filters.range == r
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(MisRadius.xs))
                                    .background(if (isSelected) MisSurface750 else Color.Transparent)
                                    .clickable { viewModel.updateReportRange(r) }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = r,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) MisTextPrimary else MisTextDim
                                )
                            }
                        }
                    }

                    // Score average readout
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${if (isAcademic) "ACADEMIC" else "LIFE"} AVG $avgScore/50",
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = accentColor
                        )
                        Text(
                            text = if (isAcademic) "${String.format("%.1f", totalHoursLogged)}h logged · ${filters.range}" else "${lifeLog?.moodScore ?: 5}/10 mood avg · ${filters.range}",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MisTextDim
                        )
                    }
                }
            }
        }

        // 3. Day Score Trajectory Chart
        item {
            MisCard(isRaised = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SCORE TRAJECTORY",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = MisTextDim
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Daily Day Scores",
                            style = MaterialTheme.typography.titleMedium,
                            color = MisTextPrimary
                        )
                    }

                    Text(
                        text = "Threshold: 35/50",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MisTextDim
                    )
                }

                Spacer(modifier = Modifier.height(MisSpacing.md))

                // Chart Surface
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(MisRadius.sm))
                        .background(MisBg950)
                        .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.sm))
                        .padding(12.dp)
                ) {
                    // Background gridlines
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        repeat(4) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .background(ChartGrid)
                            )
                        }
                    }

                    // Score data bars
                    val days = listOf("09-02", "09-03", "09-04", "09-05", "09-06", "09-07", "09-08")
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        days.forEachIndexed { index, day ->
                            val isCurrent = index == 6
                            val score = if (isCurrent) avgScore else if (index == 5) (avgScore * 0.8f).toInt() else 0
                            val barH = if (score > 0) ((score / 50f) * 95).dp else 4.dp

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(18.dp)
                                        .height(barH)
                                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                        .background(if (isCurrent) accentColor else MisSurface750)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = day.takeLast(2),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isCurrent) accentColor else MisTextDim
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. Dual Workspace Sector Audit
        item {
            MisSectionHeader(
                eyebrow = "DUAL SECTOR AUDIT",
                title = "Academic vs Biological Equilibrium"
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(MisSpacing.md)
            ) {
                // Academic Sector (Cyan)
                MisCard(
                    modifier = Modifier.weight(1f),
                    isRaised = true
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Academic500)
                            )
                            Text(
                                text = "ACADEMIC",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = Academic400
                            )
                        }
                        Text(
                            text = "${academicLog?.calculatedScore ?: 0}/50",
                            fontSize = 26.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Academic500
                        )
                        Text(
                            text = "${String.format("%.1f", totalHoursLogged)}h study · ${academicLog?.dppCompleted ?: 0} DPPs",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextDim
                        )
                    }
                }

                // Life Sector (Emerald)
                MisCard(
                    modifier = Modifier.weight(1f),
                    isRaised = true
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Life500)
                            )
                            Text(
                                text = "BIOLOGICAL",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = Life400
                            )
                        }
                        Text(
                            text = "${lifeLog?.calculatedScore ?: 0}/50",
                            fontSize = 26.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Life500
                        )
                        Text(
                            text = "${lifeLog?.moodScore ?: 5}/10 mood · ${lifeLog?.bedtime ?: "10:30 PM"} sleep",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextDim
                        )
                    }
                }
            }
        }

        // 5. Domain Consistency Telemetry
        item {
            MisSectionHeader(
                eyebrow = "DOMAIN VECTORS",
                title = if (isAcademic) "Study & Task Rhythm" else "Mood & Habit Consistency"
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(MisSpacing.md)
            ) {
                // Primary Vector
                MisCard(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isAcademic) "DEEP STUDY" else "MOOD AVERAGE",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = MisTextDim
                    )
                    Spacer(modifier = Modifier.height(MisSpacing.xs))
                    Text(
                        text = if (isAcademic) "${String.format("%.1f", totalHoursLogged)}h" else "${lifeLog?.moodScore ?: 5}/10",
                        fontSize = 24.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = accentColor
                    )
                    Text(
                        text = if (isAcademic) "hours focused today" else "affective intensity",
                        style = MaterialTheme.typography.bodySmall,
                        color = MisTextMuted
                    )
                }

                // Secondary Vector
                MisCard(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isAcademic) "DPP PAPERS" else "HABIT RATE",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = MisTextDim
                    )
                    Spacer(modifier = Modifier.height(MisSpacing.xs))
                    Text(
                        text = if (isAcademic) "${academicLog?.dppCompleted ?: 0} done" else "100%",
                        fontSize = 24.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Warning400
                    )
                    Text(
                        text = if (isAcademic) "problem sheets cleared" else "routines executed",
                        style = MaterialTheme.typography.bodySmall,
                        color = MisTextMuted
                    )
                }
            }
        }

        // 5. Historical Track Matrix (Heatmap)
        item {
            MisCard(isRaised = false) {
                Text(
                    text = "CONSISTENCY MATRIX",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = MisTextDim
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "7-Day Cross-Domain Matrix",
                    style = MaterialTheme.typography.titleMedium,
                    color = MisTextPrimary
                )

                Spacer(modifier = Modifier.height(MisSpacing.md))

                val rows = if (isAcademic) {
                    listOf("Studies", "Tasks", "DPPs", "Total Score")
                } else {
                    listOf("Habits", "Mood", "Tasks", "Well-Spent", "Wellness", "Life Score")
                }

                val colDates = listOf("Sep 2", "Sep 3", "Sep 4", "Sep 5", "Sep 6", "Sep 7", "Sep 8")

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Header dates row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "TRACK",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = MisTextDim,
                            modifier = Modifier.width(80.dp)
                        )
                        colDates.forEach { d ->
                            Text(
                                text = d.takeLast(2),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (d == "Sep 8") accentColor else MisTextDim
                            )
                        }
                    }

                    MisDividerLine()

                    rows.forEach { rowLabel ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = rowLabel,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MisTextSecondary,
                                modifier = Modifier.width(80.dp)
                            )

                            colDates.forEachIndexed { idx, _ ->
                                val isToday = idx == 6
                                val isYesterday = idx == 5
                                val isActive = isToday || (isYesterday && rowLabel != "DPPs")

                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isActive) accentColor.copy(alpha = if (isToday) 0.85f else 0.4f) else MisSurface750),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isToday) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(MisBg950)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 6. Cross-Workspace Correlation Insight (Editorial Classified Memorandum)
        item {
            MisCard(isRaised = true, highlighted = true) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Intelligence Synthesis",
                                tint = accentColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "CROSS-DOMAIN SYNTHESIS // MEMORANDUM",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp,
                                color = MisTextDim
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MisRadius.xs))
                                .background(MisSurface700)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "DISPATCH 04-A",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MisTextSecondary
                            )
                        }
                    }

                    Text(
                        text = "Peak Deep Work sessions (>4h) directly correlate with +2.2 higher Mood scores and earlier circadian sleep onset.",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontFamily = FontFamily.Serif,
                            fontSize = 15.sp,
                            lineHeight = 22.sp
                        ),
                        color = MisTextPrimary
                    )

                    Text(
                        text = "Operational recommendation: maintain morning study blocks prior to digital screen exposure to preserve cognitive stamina throughout the afternoon cycle.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MisTextMuted
                    )
                }
            }
        }

        // 7. Best Day Dossier Record
        item {
            MisCard(isRaised = false) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PEAK RECORD",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = MisTextDim
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (avgScore > 0) "Tuesday, September 8 ($avgScore/50)" else "No historical records logged in range",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (avgScore > 0) accentColor else MisTextMuted
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.TrendingUp,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(MisSpacing.lg))
        }
    }
}
