package com.example.ui.screens.academic

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AcademicLogEntity
import com.example.ui.components.MisButton
import com.example.ui.components.MisCard
import com.example.ui.components.MisCheckbox
import com.example.ui.components.MisDividerLine
import com.example.ui.components.MisHeader
import com.example.ui.components.MisSaveConfirmation
import com.example.ui.components.MisSectionHeader
import com.example.ui.components.PrioritySelector
import com.example.ui.components.ProgressRail
import com.example.ui.components.ScoreCapsule
import com.example.ui.theme.Academic400
import com.example.ui.theme.Academic500
import com.example.ui.theme.Academic900
import com.example.ui.theme.Danger400
import com.example.ui.theme.MisBg850
import com.example.ui.theme.MisBg900
import com.example.ui.theme.MisBg950
import com.example.ui.theme.MisBorder
import com.example.ui.theme.MisBorderSubtle
import com.example.ui.theme.MisDivider
import com.example.ui.theme.MisElevation
import com.example.ui.theme.MisInput
import com.example.ui.theme.MisRadius
import com.example.ui.theme.MisSpacing
import com.example.ui.theme.MisSurface750
import com.example.ui.theme.MisSurface800
import com.example.ui.theme.MisTextDim
import com.example.ui.theme.MisTextMuted
import com.example.ui.theme.MisTextPrimary
import com.example.ui.theme.MisTextSecondary
import com.example.ui.viewmodel.MisViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AcademicDailyLogScreen(
    viewModel: MisViewModel,
    modifier: Modifier = Modifier
) {
    val academicLog by viewModel.academicLog.collectAsState()
    val todos by viewModel.academicTodos.collectAsState()
    val log = academicLog ?: AcademicLogEntity(date = viewModel.todayDate)
    val coroutineScope = rememberCoroutineScope()

    val completedTodos = todos.count { it.isCompleted }
    val totalTodos = todos.size

    var newTodoTitle by remember { mutableStateOf("") }
    var newTodoTag by remember { mutableStateOf("Physics") }
    var newTodoDueDate by remember { mutableStateOf("09/08/2026") }

    var showSaveToast by remember { mutableStateOf(false) }

    // Progressive disclosure states
    var studiesExpanded by remember { mutableStateOf(true) }
    var tasksExpanded by remember { mutableStateOf(true) }
    var dppExpanded by remember { mutableStateOf(true) }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = MisSpacing.md),
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(MisSpacing.md)
        ) {
            item {
                MisHeader(
                    eyebrow = "DAILY OPERATIONAL LOG",
                    title = "Academic Log",
                    subtitle = viewModel.dateDisplayHeader
                )
            }

            // Overview Index Card
            item {
                MisCard(isFeatured = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(MisSpacing.md)
                    ) {
                        // Left Metric Tile
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(RoundedCornerShape(MisRadius.lg))
                                .background(Academic900)
                                .border(1.dp, Academic500.copy(alpha = 0.5f), RoundedCornerShape(MisRadius.lg)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${log.calculatedScore}",
                                    fontSize = 26.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Academic500
                                )
                                Text(
                                    text = "OF 50",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MisTextMuted
                                )
                            }
                        }

                        // Explanatory Copy
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.School,
                                    contentDescription = null,
                                    tint = Academic500,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Multi-Track Weighting",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MisTextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Each track is scored out of 10 with priority multipliers (High: 3×, Med: 2×, Low: 1×). Commit logs daily to maintain intelligence fidelity.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MisTextSecondary,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            // Track 1: Deep Studies
            item {
                MisCard(isRaised = true) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { studiesExpanded = !studiesExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(MisRadius.sm))
                                    .background(Academic900),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MenuBook,
                                    contentDescription = null,
                                    tint = Academic500,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Deep Study Hours",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MisTextPrimary
                                )
                                Text(
                                    text = "${String.format("%.1f", log.hoursStudied)}h / ${log.targetHours.toInt()}h target",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = MisTextDim
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val studiesScore = (log.hoursStudied / log.targetHours).coerceIn(0f, 1f) * 10f
                            ScoreCapsule(scoreText = "${String.format("%.1f", studiesScore)}/10")
                            Icon(
                                imageVector = if (studiesExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = if (studiesExpanded) "Collapse" else "Expand",
                                tint = MisTextDim,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    AnimatedVisibility(
                        visible = studiesExpanded,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column {
                            Spacer(modifier = Modifier.height(MisSpacing.md))
                            MisDividerLine()
                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            // Priority Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "TRACK PRIORITY",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = MisTextDim
                                )
                                PrioritySelector(
                                    selectedPriority = log.studiesPriority,
                                    onPrioritySelected = { viewModel.updateStudiesPriority(it) }
                                )
                            }

                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            // Hours studied slider
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Hours Logged",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MisTextPrimary
                                )
                                Text(
                                    text = "${String.format("%.1f", log.hoursStudied)}h",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Academic500,
                                    fontSize = 16.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Slider(
                                value = log.hoursStudied,
                                onValueChange = { viewModel.updateStudiesHours(it) },
                                valueRange = 0f..14f,
                                steps = 27,
                                colors = SliderDefaults.colors(
                                    thumbColor = Academic500,
                                    activeTrackColor = Academic500,
                                    inactiveTrackColor = MisDivider
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Target Allocation Slider
                            Spacer(modifier = Modifier.height(MisSpacing.sm))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Target Study Hours",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MisTextPrimary
                                )
                                Text(
                                    text = "${log.targetHours.toInt()}h target",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Academic400,
                                    fontSize = 15.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Slider(
                                value = log.targetHours,
                                onValueChange = { viewModel.updateTargetHours(it) },
                                valueRange = 1f..12f,
                                steps = 10,
                                colors = SliderDefaults.colors(
                                    thumbColor = Academic400,
                                    activeTrackColor = Academic400,
                                    inactiveTrackColor = MisDivider
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            // Track 2: Academic Tasks & Checklist
            item {
                MisCard(isRaised = true) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { tasksExpanded = !tasksExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(MisRadius.sm))
                                    .background(Academic900),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TaskAlt,
                                    contentDescription = null,
                                    tint = Academic500,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Academic Tasks",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MisTextPrimary
                                )
                                Text(
                                    text = "$completedTodos of $totalTodos tasks finished",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = MisTextDim
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val tasksScore = if (totalTodos > 0) (completedTodos.toFloat() / totalTodos) * 10f else 0f
                            ScoreCapsule(scoreText = "${String.format("%.1f", tasksScore)}/10")
                            Icon(
                                imageVector = if (tasksExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = if (tasksExpanded) "Collapse" else "Expand",
                                tint = MisTextDim,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    AnimatedVisibility(
                        visible = tasksExpanded,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column {
                            Spacer(modifier = Modifier.height(MisSpacing.md))
                            MisDividerLine()
                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            // Priority Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "TRACK PRIORITY",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = MisTextDim
                                )
                                PrioritySelector(
                                    selectedPriority = log.tasksPriority,
                                    onPrioritySelected = { viewModel.updateAcademicTasksPriority(it) }
                                )
                            }

                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            // Task input row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(MisRadius.sm))
                                        .background(MisInput)
                                        .border(1.dp, MisBorder, RoundedCornerShape(MisRadius.sm))
                                        .padding(horizontal = 12.dp, vertical = 10.dp)
                                ) {
                                    if (newTodoTitle.isEmpty()) {
                                        Text(
                                            text = "New task title...",
                                            color = MisTextDim,
                                            fontSize = 13.sp
                                        )
                                    }
                                    BasicTextField(
                                        value = newTodoTitle,
                                        onValueChange = { newTodoTitle = it },
                                        textStyle = TextStyle(color = MisTextPrimary, fontSize = 13.sp),
                                        cursorBrush = SolidColor(Academic500),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("academic_todo_input")
                                    )
                                }

                                MisButton(
                                    text = "Add",
                                    onClick = {
                                        if (newTodoTitle.isNotBlank()) {
                                            viewModel.addTodo(newTodoTitle, newTodoTag, newTodoDueDate, "ACADEMIC")
                                            newTodoTitle = ""
                                        }
                                    },
                                    icon = Icons.Default.Add,
                                    modifier = Modifier.testTag("add_todo_button")
                                )
                            }

                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            // Task items
                            if (todos.isEmpty()) {
                                Text(
                                    text = "No active academic tasks on record today.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MisTextDim
                                )
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    todos.forEach { todo ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(MisRadius.sm))
                                                .background(MisBg900)
                                                .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.sm))
                                                .padding(horizontal = 12.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                MisCheckbox(
                                                    checked = todo.isCompleted,
                                                    onCheckedChange = {
                                                        viewModel.toggleTodo(todo.id, todo.isCompleted, "ACADEMIC")
                                                    },
                                                    accentColor = Academic500
                                                )
                                                Text(
                                                    text = todo.title,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = if (todo.isCompleted) MisTextDim else MisTextPrimary
                                                )
                                            }

                                            IconButton(
                                                onClick = { viewModel.deleteTodo(todo.id, "ACADEMIC") },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Delete",
                                                    tint = MisTextDim,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Track 3: DPPs / Records
            item {
                MisCard(isRaised = true) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { dppExpanded = !dppExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(MisRadius.sm))
                                    .background(Academic900),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = null,
                                    tint = Academic500,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "DPPs & Practice Papers",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MisTextPrimary
                                )
                                Text(
                                    text = "${log.dppCompleted} completed of ${log.dppAssigned} assigned",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = MisTextDim
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val dppScore = (log.dppCompleted.toFloat() / log.dppAssigned.coerceAtLeast(1)) * 10f
                            ScoreCapsule(scoreText = "${String.format("%.1f", dppScore.coerceIn(0f, 10f))}/10")
                            Icon(
                                imageVector = if (dppExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = if (dppExpanded) "Collapse" else "Expand",
                                tint = MisTextDim,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    AnimatedVisibility(
                        visible = dppExpanded,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column {
                            Spacer(modifier = Modifier.height(MisSpacing.md))
                            MisDividerLine()
                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            // Priority Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "TRACK PRIORITY",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = MisTextDim
                                )
                                PrioritySelector(
                                    selectedPriority = log.dppPriority,
                                    onPrioritySelected = { viewModel.updateDppPriority(it) }
                                )
                            }

                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(MisSpacing.md)
                            ) {
                                // Assigned Counter
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "ASSIGNED PAPERS",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp,
                                        color = MisTextDim
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(MisRadius.sm))
                                            .background(MisInput)
                                            .border(1.dp, MisBorder, RoundedCornerShape(MisRadius.sm))
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${log.dppAssigned}",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = MisTextPrimary,
                                            fontSize = 16.sp
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(MisSurface750)
                                                    .clickable { viewModel.updateDppAssigned(log.dppAssigned - 1) },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("-", color = MisTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(MisSurface750)
                                                    .clickable { viewModel.updateDppAssigned(log.dppAssigned + 1) },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("+", color = MisTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                            }
                                        }
                                    }
                                }

                                // Completed Counter
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "COMPLETED PAPERS",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp,
                                        color = MisTextDim
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(MisRadius.sm))
                                            .background(MisInput)
                                            .border(1.dp, MisBorder, RoundedCornerShape(MisRadius.sm))
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${log.dppCompleted}",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = Academic500,
                                            fontSize = 16.sp
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(MisSurface750)
                                                    .clickable { viewModel.updateDppCompleted(log.dppCompleted - 1) },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("-", color = MisTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(MisSurface750)
                                                    .clickable { viewModel.updateDppCompleted(log.dppCompleted + 1) },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("+", color = MisTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Sticky Bottom Commitment Action Bar
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            color = MisBg950.copy(alpha = 0.95f),
            tonalElevation = MisElevation.level4
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        brush = Brush.horizontalGradient(
                            listOf(Color.Transparent, MisBorderSubtle, Color.Transparent)
                        ),
                        shape = RoundedCornerShape(topStart = MisRadius.xl, topEnd = MisRadius.xl)
                    )
                    .padding(horizontal = MisSpacing.md, vertical = MisSpacing.sm),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                MisSaveConfirmation(visible = showSaveToast)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "TODAY'S INDEX",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = MisTextDim
                        )
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "${log.calculatedScore}",
                                fontSize = 24.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Academic500
                            )
                            Text(
                                text = " / 50",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MisTextMuted,
                                modifier = Modifier.padding(bottom = 3.dp, start = 2.dp)
                            )
                        }
                    }

                    MisButton(
                        text = "Commit Log",
                        onClick = {
                            viewModel.saveAcademicLog()
                            showSaveToast = true
                            coroutineScope.launch {
                                delay(2500)
                                showSaveToast = false
                            }
                        },
                        icon = Icons.Default.CheckCircle,
                        modifier = Modifier.testTag("commit_academic_log_button")
                    )
                }
            }
        }
    }
}
