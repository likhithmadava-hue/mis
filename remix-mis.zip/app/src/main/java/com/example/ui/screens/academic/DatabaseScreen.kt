package com.example.ui.screens.academic

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MistakeEntity
import com.example.ui.components.MisButton
import com.example.ui.components.MisCard
import com.example.ui.components.MisDividerLine
import com.example.ui.components.MisEmptyState
import com.example.ui.components.MisHeader
import com.example.ui.components.PulseBeacon
import com.example.ui.theme.Academic400
import com.example.ui.theme.Academic500
import com.example.ui.theme.Academic900
import com.example.ui.theme.Danger400
import com.example.ui.theme.Danger500
import com.example.ui.theme.DangerBg
import com.example.ui.theme.DangerBorder
import com.example.ui.theme.MisBg850
import com.example.ui.theme.MisBg900
import com.example.ui.theme.MisBg950
import com.example.ui.theme.MisBorder
import com.example.ui.theme.MisBorderStrong
import com.example.ui.theme.MisBorderSubtle
import com.example.ui.theme.MisDivider
import com.example.ui.theme.MisElevation
import com.example.ui.theme.MisInput
import com.example.ui.theme.MisRadius
import com.example.ui.theme.MisSpacing
import com.example.ui.theme.MisSurface750
import com.example.ui.theme.MisSurface800
import com.example.ui.theme.MisTextDim
import com.example.ui.theme.MisTextMuted
import com.example.ui.theme.MisTextPrimary
import com.example.ui.theme.MisTextSecondary
import com.example.ui.theme.Warning400
import com.example.ui.theme.Warning500
import com.example.ui.theme.WarningBg
import com.example.ui.theme.WarningBorder
import com.example.ui.viewmodel.MisViewModel

@Composable
fun DatabaseScreen(
    viewModel: MisViewModel,
    modifier: Modifier = Modifier
) {
    val mistakes by viewModel.allMistakes.collectAsState()
    val filters by viewModel.databaseFilters.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }

    // Filter logic
    val filteredMistakes = mistakes.filter { mistake ->
        val matchesSearch = filters.searchQuery.isEmpty() ||
                mistake.title.contains(filters.searchQuery, ignoreCase = true) ||
                mistake.chapter.contains(filters.searchQuery, ignoreCase = true) ||
                mistake.notes.contains(filters.searchQuery, ignoreCase = true)

        val matchesSubject = filters.subject == "All subjects" || mistake.subject.equals(filters.subject, ignoreCase = true)
        val matchesErrorType = filters.errorType == "All errors" || mistake.errorType.equals(filters.errorType, ignoreCase = true)
        val matchesDifficulty = filters.difficulty == "Any difficulty" || mistake.difficulty.equals(filters.difficulty, ignoreCase = true)

        matchesSearch && matchesSubject && matchesErrorType && matchesDifficulty
    }

    val totalMarksLost = filteredMistakes.sumOf { it.marksLost }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = MisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(MisSpacing.md)
    ) {
        item {
            MisHeader(
                eyebrow = "ACADEMIC ANOMALY REPOSITORY",
                title = "Mistake Intelligence",
                subtitle = viewModel.dateDisplayHeader,
                trailingContent = {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Diagnostic Button for Database Error
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MisRadius.xs))
                                .background(MisSurface800)
                                .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.xs))
                                .clickable { viewModel.testTriggerDbError() }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("test_db_error_trigger")
                        ) {
                            Text(
                                text = "TEST DB FAULT",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Danger400
                            )
                        }

                        // Diagnostic Button for API Error
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MisRadius.xs))
                                .background(MisSurface800)
                                .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.xs))
                                .clickable { viewModel.testTriggerApiError() }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("test_api_error_trigger")
                        ) {
                            Text(
                                text = "TEST API FAULT",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Warning400
                            )
                        }
                    }
                }
            )
        }

        // Search & Filters Dossier Query Bar
        item {
            MisCard(isRaised = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "ANOMALY QUERY ENGINE",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp,
                                color = Academic400
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Search, triage, and eradicate recurring cognitive errors.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MisTextDim
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MisButton(
                            text = "Cloud Sync",
                            onClick = { viewModel.syncCloudTelemetry() },
                            isPrimary = false,
                            icon = Icons.Default.Sync,
                            modifier = Modifier.testTag("cloud_sync_button")
                        )
                        MisButton(
                            text = "Import",
                            onClick = { viewModel.importSampleMistakes() },
                            isPrimary = false,
                            icon = Icons.Default.Upload
                        )
                        MisButton(
                            text = "+ Log Anomaly",
                            onClick = { showAddDialog = true },
                            isPrimary = true,
                            icon = Icons.Default.Add,
                            modifier = Modifier.testTag("add_mistake_button")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(MisSpacing.md))

                // Terminal Command Line Query Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(MisRadius.sm))
                        .background(MisInput)
                        .border(1.dp, MisBorderStrong, RoundedCornerShape(MisRadius.sm))
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "QUERY://",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Academic500
                        )
                        Box(modifier = Modifier.weight(1f)) {
                            if (filters.searchQuery.isEmpty()) {
                                Text(
                                    text = "regex / keyword / concept search...",
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MisTextDim
                                )
                            }
                            BasicTextField(
                                value = filters.searchQuery,
                                onValueChange = { viewModel.updateDatabaseSearch(it) },
                                textStyle = TextStyle(
                                    color = MisTextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp
                                ),
                                cursorBrush = SolidColor(Academic500),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("search_mistakes_input")
                            )
                        }
                        if (filters.searchQuery.isNotEmpty()) {
                            Text(
                                text = "ESC",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MisTextDim,
                                modifier = Modifier
                                    .clickable { viewModel.updateDatabaseSearch("") }
                                    .padding(2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(MisSpacing.sm))

                // Subject Filter Bar (Tactile segmented capsules)
                val subjects = listOf("All subjects", "Physics", "Chemistry", "Math", "Biology")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    subjects.forEach { subject ->
                        val isSelected = filters.subject == subject
                        val count = if (subject == "All subjects") {
                            mistakes.size
                        } else {
                            mistakes.count { it.subject.equals(subject, ignoreCase = true) }
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MisRadius.xs))
                                .background(if (isSelected) Academic900 else MisInput)
                                .border(
                                    1.dp,
                                    if (isSelected) Academic500 else MisBorderSubtle,
                                    RoundedCornerShape(MisRadius.xs)
                                )
                                .clickable { viewModel.updateDatabaseSubject(subject) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = subject.uppercase(),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Academic500 else MisTextSecondary
                                )
                                Text(
                                    text = "$count",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isSelected) Academic400 else MisTextDim
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Error Classification Segmented Pills
                val errors = listOf("All errors", "Calculation", "Conceptual", "Silly mistake", "Formula recall")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    errors.forEach { err ->
                        val isSelected = filters.errorType == err
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MisRadius.xs))
                                .background(if (isSelected) Academic900 else MisInput)
                                .border(
                                    1.dp,
                                    if (isSelected) Academic500 else MisBorderSubtle,
                                    RoundedCornerShape(MisRadius.xs)
                                )
                                .clickable { viewModel.updateDatabaseErrorType(err) }
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = err,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Academic500 else MisTextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Forensic Dossier Anomaly Records or Empty State
        if (filteredMistakes.isEmpty()) {
            item {
                MisEmptyState(
                    title = "No Cognitive Anomalies Found",
                    description = "Current query matches zero recorded errors in the knowledge graph.",
                    categoryCode = "ANOMALY_INDEX_EMPTY // 00_MATCHES",
                    actionText = "Load Sample Knowledge Base",
                    onActionClick = { viewModel.importSampleMistakes() }
                )
            }
        } else {
            items(filteredMistakes, key = { it.id }) { mistake ->
                // Forensic Dossier Card
                MisCard(isRaised = true) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Header Strip: ID & Severity & Recurrence & Actions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "ERR-${String.format("%04d", mistake.id)}",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = MisTextDim
                                )

                                // Subject Tag
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Academic900)
                                        .border(1.dp, Academic500.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = mistake.subject.uppercase(),
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = Academic400
                                    )
                                }

                                // Error Type Classification
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MisSurface750)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = mistake.errorType,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = Warning400
                                    )
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // Marks Lost Badge
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(DangerBg)
                                        .border(1.dp, DangerBorder, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "-${mistake.marksLost} MARKS",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = Danger400
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.deleteMistake(mistake.id) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete Anomaly",
                                        tint = MisTextDim,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }

                        // Title / Question
                        Text(
                            text = mistake.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MisTextPrimary
                        )

                        // Chapter Subtext
                        if (mistake.chapter.isNotBlank()) {
                            Text(
                                text = "SECTION: ${mistake.chapter}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MisTextDim
                            )
                        }

                        // Corrective Protocol / Notes Box
                        if (mistake.notes.isNotEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(MisRadius.xs))
                                    .background(MisBg950)
                                    .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.xs))
                                    .padding(8.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = "CORRECTIVE PROTOCOL //",
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp,
                                        color = Academic400
                                    )
                                    Text(
                                        text = mistake.notes,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MisTextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Database Summary Telemetry Strip
        item {
            MisCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DOSSIER ARCHIVE: ${filteredMistakes.size} / ${mistakes.size} QUERIED",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MisTextDim
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(MisRadius.xs))
                            .background(DangerBg)
                            .border(1.dp, DangerBorder, RoundedCornerShape(MisRadius.xs))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "AGGREGATE LOSS: -$totalMarksLost PTS",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Danger400
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(MisSpacing.lg))
        }
    }

    // Add Mistake Dialog
    if (showAddDialog) {
        AddMistakeDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { title, subject, chapter, errorType, difficulty, marksLost, notes ->
                viewModel.addMistake(title, subject, chapter, errorType, difficulty, marksLost, notes)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun AddMistakeDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String, String, String, String, Int, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("Physics") }
    var chapter by remember { mutableStateOf("") }
    var errorType by remember { mutableStateOf("Conceptual") }
    var difficulty by remember { mutableStateOf("Medium") }
    var marksLost by remember { mutableStateOf("3") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "LOG COGNITIVE ANOMALY",
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp,
                color = Academic400
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Title
                Text(
                    text = "QUESTION / PHENOMENON",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = MisTextDim
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(MisRadius.xs))
                        .background(MisInput)
                        .border(1.dp, MisBorder, RoundedCornerShape(MisRadius.xs))
                        .padding(10.dp)
                ) {
                    BasicTextField(
                        value = title,
                        onValueChange = { title = it },
                        textStyle = TextStyle(color = MisTextPrimary, fontSize = 13.sp),
                        cursorBrush = SolidColor(Academic500),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_title_input")
                    )
                }

                // Subject & Chapter
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "SUBJECT",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MisTextDim
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(MisRadius.xs))
                                .background(MisInput)
                                .border(1.dp, MisBorder, RoundedCornerShape(MisRadius.xs))
                                .padding(10.dp)
                        ) {
                            BasicTextField(
                                value = subject,
                                onValueChange = { subject = it },
                                textStyle = TextStyle(color = MisTextPrimary, fontSize = 13.sp),
                                cursorBrush = SolidColor(Academic500),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "CHAPTER",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MisTextDim
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(MisRadius.xs))
                                .background(MisInput)
                                .border(1.dp, MisBorder, RoundedCornerShape(MisRadius.xs))
                                .padding(10.dp)
                        ) {
                            BasicTextField(
                                value = chapter,
                                onValueChange = { chapter = it },
                                textStyle = TextStyle(color = MisTextPrimary, fontSize = 13.sp),
                                cursorBrush = SolidColor(Academic500),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // Error type & Marks lost
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1.4f)) {
                        Text(
                            text = "CLASSIFICATION",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MisTextDim
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(MisRadius.xs))
                                .background(MisInput)
                                .border(1.dp, MisBorder, RoundedCornerShape(MisRadius.xs))
                                .padding(10.dp)
                        ) {
                            BasicTextField(
                                value = errorType,
                                onValueChange = { errorType = it },
                                textStyle = TextStyle(color = MisTextPrimary, fontSize = 13.sp),
                                cursorBrush = SolidColor(Academic500),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "MARKS LOST",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MisTextDim
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(MisRadius.xs))
                                .background(MisInput)
                                .border(1.dp, MisBorder, RoundedCornerShape(MisRadius.xs))
                                .padding(10.dp)
                        ) {
                            BasicTextField(
                                value = marksLost,
                                onValueChange = { marksLost = it },
                                textStyle = TextStyle(color = MisTextPrimary, fontSize = 13.sp),
                                cursorBrush = SolidColor(Academic500),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // Notes
                Text(
                    text = "CORRECTIVE PROTOCOL / LEARNING",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = MisTextDim
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .clip(RoundedCornerShape(MisRadius.xs))
                        .background(MisInput)
                        .border(1.dp, MisBorder, RoundedCornerShape(MisRadius.xs))
                        .padding(10.dp)
                ) {
                    BasicTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        textStyle = TextStyle(color = MisTextSecondary, fontSize = 12.sp),
                        cursorBrush = SolidColor(Academic500),
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        },
        confirmButton = {
            MisButton(
                text = "Commit Anomaly",
                onClick = {
                    if (title.isNotBlank()) {
                        val marks = marksLost.toIntOrNull() ?: 1
                        onAdd(title, subject, chapter, errorType, difficulty, marks, notes)
                    }
                },
                modifier = Modifier.testTag("dialog_save_button")
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = "ABORT",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MisTextDim
                )
            }
        },
        containerColor = MisSurface800
    )
}
