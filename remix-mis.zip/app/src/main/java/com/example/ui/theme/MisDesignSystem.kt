package com.example.ui.theme

import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * MIS (Mistake Intelligence System) Design System Foundations
 *
 * Systematized 4/8pt spacing scale, strict radius tokens,
 * icon size tokens, and elevation levels.
 */
object MisSpacing {
    val xxs: Dp = 4.dp     // Micro spacing: badge padding, tight icon margins
    val xs: Dp = 8.dp      // Compact spacing: chip margins, internal row gaps
    val sm: Dp = 12.dp     // Regular spacing: form field vertical gaps, subtitle offsets
    val md: Dp = 16.dp     // Standard screen margin, card inner horizontal padding
    val lg: Dp = 20.dp     // Generous card padding, section gap
    val xl: Dp = 24.dp     // Major section header spacing
    val xxl: Dp = 32.dp    // Screen boundaries, hero gauge clearances
    val xxxl: Dp = 48.dp   // Empty state vertical breathing space
}

object MisRadius {
    val xs: Dp = 4.dp      // Micro badges, indicator pills
    val sm: Dp = 8.dp      // Priority chips, secondary buttons, tags
    val md: Dp = 12.dp     // Primary buttons, text inputs, segmented items
    val lg: Dp = 16.dp     // Dialogs, standard cards
    val xl: Dp = 20.dp     // Featured cards, hero gauges, primary panels
    val pill: Dp = 999.dp  // Round status pills, capsule scores, floating pills
    val full: Dp = 999.dp  // Complete pill curvature alias
}

object MisIconSize {
    val sm: Dp = 14.dp     // Inline metadata icons, mini status markers
    val md: Dp = 18.dp     // Standard button icons, card action affordances
    val lg: Dp = 24.dp     // Navigation bar icons, major header icons
    val xl: Dp = 32.dp     // Hero empty states, prominent gauges
}

object MisElevation {
    val level0: Dp = 0.dp  // Deep canvas background (MisBg950)
    val level1: Dp = 2.dp  // Recessed elements, secondary cards (MisSurface800)
    val level2: Dp = 4.dp  // Raised cards, actionable list items (MisSurface750)
    val level3: Dp = 8.dp  // Modal sheets, bottom actions, active focal cards (MisSurface700)
    val level4: Dp = 12.dp // Floating drawers, active dialogs
}

/**
 * Motion and easing duration tokens for purposeful micro-interactions.
 */
object MisMotion {
    const val durationFastMs: Int = 150     // Toggles, active state ripples, micro-scales
    const val durationDefaultMs: Int = 250  // Card reveals, expandable trays, chips
    const val durationModerateMs: Int = 350 // Workspace morphs, modal overlays
    const val durationLongMs: Int = 500     // Hero dial sweeps, metric springs
}

