package com.example.ui.screens.life

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LifeLogEntity
import com.example.ui.components.CircularScoreGauge
import com.example.ui.components.MisCard
import com.example.ui.components.MisCheckbox
import com.example.ui.components.MisDividerLine
import com.example.ui.components.MisHeader
import com.example.ui.components.PrioritySelector
import com.example.ui.components.ProgressRail
import com.example.ui.components.ScoreCapsule
import com.example.ui.theme.Danger500
import com.example.ui.theme.Life300
import com.example.ui.theme.Life400
import com.example.ui.theme.Life500
import com.example.ui.theme.Life800
import com.example.ui.theme.Life900
import com.example.ui.theme.Life950
import com.example.ui.theme.MisBg850
import com.example.ui.theme.MisBg900
import com.example.ui.theme.MisBg950
import com.example.ui.theme.MisBorder
import com.example.ui.theme.MisBorderSubtle
import com.example.ui.theme.MisDivider
import com.example.ui.theme.MisElevation
import com.example.ui.theme.MisInput
import com.example.ui.theme.MisRadius
import com.example.ui.theme.MisSpacing
import com.example.ui.theme.MisSurface700
import com.example.ui.theme.MisSurface750
import com.example.ui.theme.MisSurface800
import com.example.ui.theme.MisTextDim
import com.example.ui.theme.MisTextMuted
import com.example.ui.theme.MisTextPrimary
import com.example.ui.theme.MisTextSecondary
import com.example.ui.theme.Warning400
import com.example.ui.theme.Warning500
import com.example.ui.viewmodel.MisViewModel
import kotlinx.coroutines.launch

@Composable
fun LifeDailyLogScreen(
    viewModel: MisViewModel,
    modifier: Modifier = Modifier
) {
    val lifeLog by viewModel.lifeLog.collectAsState()
    val habits by viewModel.allHabits.collectAsState()
    val todos by viewModel.lifeTodos.collectAsState()
    val log = lifeLog ?: LifeLogEntity(date = viewModel.todayDate)

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var newHabitTitle by remember { mutableStateOf("") }
    var newHabitPriority by remember { mutableStateOf("MEDIUM") }

    var bedtimeText by remember { mutableStateOf(log.bedtime) }
    var wakeTimeText by remember { mutableStateOf(log.wakeTime) }

    // Section collapse states for progressive disclosure
    var habitsExpanded by remember { mutableStateOf(true) }
    var moodExpanded by remember { mutableStateOf(true) }
    var leisureExpanded by remember { mutableStateOf(true) }
    var wellnessExpanded by remember { mutableStateOf(true) }

    val moodDescriptor = when (log.moodScore) {
        in 9..10 -> "PEAK FLOW (9-10)"
        in 7..8 -> "GROUNDED (7-8)"
        in 5..6 -> "BALANCED (5-6)"
        in 3..4 -> "FATIGUED (3-4)"
        else -> "DEPLETED (0-2)"
    }

    val moodColor = when (log.moodScore) {
        in 7..10 -> Life400
        in 5..6 -> Warning400
        else -> Danger500
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = MisSpacing.md),
            verticalArrangement = Arrangement.spacedBy(MisSpacing.md)
        ) {
            // 1. Header
            item {
                MisHeader(
                    eyebrow = "DAILY CALIBRATION",
                    title = "Life Log",
                    subtitle = viewModel.dateDisplayHeader
                )
            }

            // 2. Score Calibration Hero Card
            item {
                MisCard(isRaised = true, highlighted = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(MisRadius.xs))
                                    .background(Life900)
                                    .border(1.dp, Life500.copy(alpha = 0.3f), RoundedCornerShape(MisRadius.xs))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "SUSTAINABILITY INDEX",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = Life400
                                )
                            }
                            Spacer(modifier = Modifier.height(MisSpacing.xs))
                            Text(
                                text = "Daily Harmony Log",
                                style = MaterialTheme.typography.headlineSmall,
                                color = MisTextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Weighted priority scoring: High = 3×, Med = 2×, Low = 1×.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MisTextDim
                            )
                        }

                        CircularScoreGauge(
                            score = log.calculatedScore,
                            maxScore = 50,
                            size = 80,
                            accentColor = Life500
                        )
                    }

                    Spacer(modifier = Modifier.height(MisSpacing.sm))
                    ProgressRail(
                        progress = (log.calculatedScore / 50f).coerceIn(0f, 1f),
                        fillColor = Life500,
                        height = 6
                    )
                }
            }

            // 3. Track 1: Habit Architecture
            item {
                MisCard(isRaised = false) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { habitsExpanded = !habitsExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(MisSpacing.xs)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(MisRadius.sm))
                                    .background(Life900),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Spa,
                                    contentDescription = null,
                                    tint = Life400,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Habit Architecture",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MisTextPrimary
                                )
                                Text(
                                    text = "${habits.count { it.isCompletedToday }} of ${habits.size} checked",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MisTextDim
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(MisSpacing.xs)
                        ) {
                            PrioritySelector(
                                selectedPriority = log.habitsPriority,
                                onPrioritySelected = { viewModel.updateHabitsPriority(it) }
                            )
                            Icon(
                                imageVector = if (habitsExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = null,
                                tint = MisTextDim,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    AnimatedVisibility(
                        visible = habitsExpanded,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column {
                            Spacer(modifier = Modifier.height(MisSpacing.md))
                            MisDividerLine()
                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            // Habit rows
                            if (habits.isEmpty()) {
                                Text(
                                    text = "No active routines established. Add your first routine below.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MisTextMuted
                                )
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    habits.forEach { habit ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(MisRadius.sm))
                                                .background(MisSurface750)
                                                .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.sm))
                                                .padding(horizontal = 12.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                MisCheckbox(
                                                    checked = habit.isCompletedToday,
                                                    onCheckedChange = {
                                                        viewModel.toggleHabit(habit.id, habit.isCompletedToday)
                                                    },
                                                    accentColor = Life500
                                                )
                                                Column {
                                                    Text(
                                                        text = habit.title,
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        color = if (habit.isCompletedToday) MisTextDim else MisTextPrimary
                                                    )
                                                    if (habit.streak > 0) {
                                                        Text(
                                                            text = "${habit.streak}d streak",
                                                            fontSize = 10.sp,
                                                            fontFamily = FontFamily.Monospace,
                                                            color = Life400
                                                        )
                                                    }
                                                }
                                            }

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                PrioritySelector(
                                                    selectedPriority = habit.priority,
                                                    onPrioritySelected = { viewModel.updateHabitPriority(habit.id, it) }
                                                )
                                                IconButton(
                                                    onClick = { viewModel.deleteHabit(habit.id) },
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = "Delete",
                                                        tint = MisTextDim,
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            // Add routine field
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(MisRadius.sm))
                                        .background(MisInput)
                                        .border(1.dp, MisBorder, RoundedCornerShape(MisRadius.sm))
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    if (newHabitTitle.isEmpty()) {
                                        Text(text = "Define routine...", color = MisTextDim, fontSize = 12.sp)
                                    }
                                    BasicTextField(
                                        value = newHabitTitle,
                                        onValueChange = { newHabitTitle = it },
                                        textStyle = TextStyle(color = MisTextPrimary, fontSize = 12.sp),
                                        cursorBrush = SolidColor(Life500),
                                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                        keyboardActions = KeyboardActions(onDone = {
                                            if (newHabitTitle.isNotBlank()) {
                                                viewModel.addHabit(newHabitTitle, newHabitPriority)
                                                newHabitTitle = ""
                                            }
                                        }),
                                        modifier = Modifier.fillMaxWidth().testTag("habit_input")
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(MisRadius.sm))
                                        .background(Life500)
                                        .clickable {
                                            if (newHabitTitle.isNotBlank()) {
                                                viewModel.addHabit(newHabitTitle, newHabitPriority)
                                                newHabitTitle = ""
                                            }
                                        }
                                        .padding(horizontal = 14.dp, vertical = 9.dp)
                                        .testTag("add_habit_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "+ ADD",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = MisBg950
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 4. Track 2: Mood Spectrum
            item {
                MisCard(isRaised = false) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { moodExpanded = !moodExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(MisSpacing.xs)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(MisRadius.sm))
                                    .background(MisBg900),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mood,
                                    contentDescription = null,
                                    tint = moodColor,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Affective State",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MisTextPrimary
                                )
                                Text(
                                    text = moodDescriptor,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = moodColor,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(MisSpacing.xs)
                        ) {
                            PrioritySelector(
                                selectedPriority = log.moodPriority,
                                onPrioritySelected = { viewModel.updateMoodPriority(it) }
                            )
                            Icon(
                                imageVector = if (moodExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = null,
                                tint = MisTextDim,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    AnimatedVisibility(
                        visible = moodExpanded,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column {
                            Spacer(modifier = Modifier.height(MisSpacing.md))
                            MisDividerLine()
                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Biometric spectrum rating",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MisTextPrimary
                                )
                                Text(
                                    text = "${log.moodScore}/10",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = moodColor,
                                    fontSize = 15.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(MisSpacing.xs))

                            Slider(
                                value = log.moodScore.toFloat(),
                                onValueChange = { viewModel.updateMoodScore(it.toInt()) },
                                valueRange = 0f..10f,
                                steps = 9,
                                colors = SliderDefaults.colors(
                                    thumbColor = moodColor,
                                    activeTrackColor = moodColor,
                                    inactiveTrackColor = MisDivider
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Spectrum marker labels
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "0 DEPLETED", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Danger500)
                                Text(text = "5 BALANCED", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Warning400)
                                Text(text = "10 FLOW", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Life400)
                            }
                        }
                    }
                }
            }

            // 5. Track 3: Well-Spent Leisure
            item {
                MisCard(isRaised = false) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { leisureExpanded = !leisureExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(MisSpacing.xs)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(MisRadius.sm))
                                    .background(MisBg900),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = null,
                                    tint = Warning500,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Intentional Leisure",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MisTextPrimary
                                )
                                Text(
                                    text = "${log.leisureMinutes} minutes logged",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MisTextDim
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(MisSpacing.xs)
                        ) {
                            PrioritySelector(
                                selectedPriority = log.wellSpentPriority,
                                onPrioritySelected = { viewModel.updateWellSpentPriority(it) }
                            )
                            Icon(
                                imageVector = if (leisureExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = null,
                                tint = MisTextDim,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    AnimatedVisibility(
                        visible = leisureExpanded,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column {
                            Spacer(modifier = Modifier.height(MisSpacing.md))
                            MisDividerLine()
                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Restoration Duration",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MisTextPrimary
                                )
                                Text(
                                    text = "${log.leisureMinutes}m",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Warning400,
                                    fontSize = 15.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(MisSpacing.xs))

                            Slider(
                                value = log.leisureMinutes.toFloat(),
                                onValueChange = { viewModel.updateLeisureMinutes(it.toInt()) },
                                valueRange = 0f..180f,
                                steps = 11, // 15m intervals
                                colors = SliderDefaults.colors(
                                    thumbColor = Warning400,
                                    activeTrackColor = Warning500,
                                    inactiveTrackColor = MisDivider
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "0m", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = MisTextDim)
                                Text(text = "60m (optimal)", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = MisTextDim)
                                Text(text = "180m", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = MisTextDim)
                            }
                        }
                    }
                }
            }

            // 6. Track 4: Biological Protocols (Hydration, Posture & Circadian)
            item {
                MisCard(isRaised = false) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { wellnessExpanded = !wellnessExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(MisSpacing.xs)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(MisRadius.sm))
                                    .background(Life900),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WaterDrop,
                                    contentDescription = null,
                                    tint = Life400,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Biological Protocols",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MisTextPrimary
                                )
                                Text(
                                    text = "Hydration, posture & circadian window",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MisTextDim
                                )
                            }
                        }

                        Icon(
                            imageVector = if (wellnessExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = null,
                            tint = MisTextDim,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    AnimatedVisibility(
                        visible = wellnessExpanded,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column {
                            Spacer(modifier = Modifier.height(MisSpacing.md))
                            MisDividerLine()
                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            // Hydration & Posture Grid
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(MisSpacing.md)
                            ) {
                                // Hydration Pod
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(MisRadius.md))
                                        .background(MisSurface750)
                                        .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.md))
                                        .padding(12.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "HYDRATION",
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace,
                                                color = MisTextDim
                                            )
                                            Text(
                                                text = "${log.hydrationCups}/${log.maxHydration}",
                                                fontSize = 12.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                color = Life400
                                            )
                                        }

                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(28.dp)
                                                    .clip(RoundedCornerShape(MisRadius.xs))
                                                    .background(MisInput)
                                                    .clickable { viewModel.decrementHydration() },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("-", color = MisTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .size(28.dp)
                                                    .clip(RoundedCornerShape(MisRadius.xs))
                                                    .background(Life500)
                                                    .clickable { viewModel.incrementHydration() },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("+", color = MisBg950, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                            }
                                        }
                                    }
                                }

                                // Posture Pod
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(MisRadius.md))
                                        .background(MisSurface750)
                                        .border(1.dp, MisBorderSubtle, RoundedCornerShape(MisRadius.md))
                                        .padding(12.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "POSTURE",
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace,
                                                color = MisTextDim
                                            )
                                            Text(
                                                text = "${log.postureChecks}/${log.maxPosture}",
                                                fontSize = 12.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                color = MisTextPrimary
                                            )
                                        }

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(MisRadius.xs))
                                                .background(MisInput)
                                                .clickable { viewModel.incrementPosture() }
                                                .padding(horizontal = 10.dp, vertical = 6.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("+ Check", color = MisTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(MisSpacing.md))

                            // Circadian Arc inputs
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(MisSpacing.md)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Bedtime Target",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = MisTextDim
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(MisRadius.sm))
                                            .background(MisInput)
                                            .border(1.dp, MisBorder, RoundedCornerShape(MisRadius.sm))
                                            .padding(10.dp)
                                    ) {
                                        BasicTextField(
                                            value = bedtimeText,
                                            onValueChange = {
                                                bedtimeText = it
                                                viewModel.updateSleepWindow(it, wakeTimeText)
                                            },
                                            textStyle = TextStyle(color = MisTextPrimary, fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                                            cursorBrush = SolidColor(Life500),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Wake Target",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = MisTextDim
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(MisRadius.sm))
                                            .background(MisInput)
                                            .border(1.dp, MisBorder, RoundedCornerShape(MisRadius.sm))
                                            .padding(10.dp)
                                    ) {
                                        BasicTextField(
                                            value = wakeTimeText,
                                            onValueChange = {
                                                wakeTimeText = it
                                                viewModel.updateSleepWindow(bedtimeText, it)
                                            },
                                            textStyle = TextStyle(color = MisTextPrimary, fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                                            cursorBrush = SolidColor(Life500),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Bottom space for floating footer
            item {
                Spacer(modifier = Modifier.height(88.dp))
            }
        }

        // 7. Sticky Footer Action Bar
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(MisBg950.copy(alpha = 0.94f))
                .border(1.dp, MisBorderSubtle)
                .padding(horizontal = MisSpacing.md, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LIVE LIFE SCORE",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = MisTextDim
                    )
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "${log.calculatedScore}",
                            fontSize = 24.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Life500
                        )
                        Text(
                            text = "/ 50",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MisTextMuted
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(MisRadius.md))
                        .background(Life500)
                        .clickable {
                            viewModel.saveLifeLog()
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Life log telemetry synchronized")
                            }
                        }
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                        .testTag("commit_life_log_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = MisBg950,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "COMMIT LOG ENTRY",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp,
                            color = MisBg950
                        )
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 80.dp)
        )
    }
}
