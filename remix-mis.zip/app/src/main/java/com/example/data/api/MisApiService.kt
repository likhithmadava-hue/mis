package com.example.data.api

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

@JsonClass(generateAdapter = true)
data class ApiDirectiveQuote(
    @Json(name = "text") val text: String,
    @Json(name = "author") val author: String,
    @Json(name = "category") val category: String? = null
)

@JsonClass(generateAdapter = true)
data class SyncTelemetryPayload(
    @Json(name = "date") val date: String,
    @Json(name = "academicScore") val academicScore: Int,
    @Json(name = "hoursStudied") val hoursStudied: Float,
    @Json(name = "totalAnomalies") val totalAnomalies: Int,
    @Json(name = "deviceTimestamp") val deviceTimestamp: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class SyncResponse(
    @Json(name = "status") val status: String,
    @Json(name = "syncId") val syncId: String,
    @Json(name = "syncedAt") val syncedAt: Long
)

interface MisApiService {
    @GET("api/v1/mis/quotes/daily")
    suspend fun getDailyQuote(): ApiDirectiveQuote

    @POST("api/v1/mis/telemetry/sync")
    suspend fun syncTelemetry(@Body payload: SyncTelemetryPayload): SyncResponse

    @GET("api/v1/mis/status/{code}")
    suspend fun simulateStatus(@Path("code") code: Int): Response<Unit>
}
