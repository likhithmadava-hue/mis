package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AcademicLogEntity
import com.example.data.model.AppScreenTimeEntity
import com.example.data.model.HabitEntity
import com.example.data.model.LifeLogEntity
import com.example.data.model.MistakeEntity
import com.example.data.model.TodoItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AcademicLogDao {
    @Query("SELECT * FROM academic_logs WHERE date = :date LIMIT 1")
    fun getLogForDate(date: String): Flow<AcademicLogEntity?>

    @Query("SELECT * FROM academic_logs ORDER BY date DESC")
    fun getAllLogs(): Flow<List<AcademicLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(log: AcademicLogEntity)
}

@Dao
interface LifeLogDao {
    @Query("SELECT * FROM life_logs WHERE date = :date LIMIT 1")
    fun getLogForDate(date: String): Flow<LifeLogEntity?>

    @Query("SELECT * FROM life_logs ORDER BY date DESC")
    fun getAllLogs(): Flow<List<LifeLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(log: LifeLogEntity)
}

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits ORDER BY orderIndex ASC, id ASC")
    fun getAllHabits(): Flow<List<HabitEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(habit: HabitEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(habits: List<HabitEntity>)

    @Update
    suspend fun update(habit: HabitEntity)

    @Query("UPDATE habits SET isCompletedToday = :completed WHERE id = :id")
    suspend fun setCompleted(id: Long, completed: Boolean)

    @Query("UPDATE habits SET priority = :priority WHERE id = :id")
    suspend fun updatePriority(id: Long, priority: String)

    @Query("DELETE FROM habits WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface TodoDao {
    @Query("SELECT * FROM todos WHERE workspace = :workspace ORDER BY isCompleted ASC, id DESC")
    fun getTodos(workspace: String): Flow<List<TodoItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(todo: TodoItemEntity): Long

    @Update
    suspend fun update(todo: TodoItemEntity)

    @Query("UPDATE todos SET isCompleted = :completed WHERE id = :id")
    suspend fun setCompleted(id: Long, completed: Boolean)

    @Query("DELETE FROM todos WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface MistakeDao {
    @Query("SELECT * FROM mistakes ORDER BY id DESC")
    fun getAllMistakes(): Flow<List<MistakeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(mistake: MistakeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(mistakes: List<MistakeEntity>)

    @Update
    suspend fun update(mistake: MistakeEntity)

    @Query("DELETE FROM mistakes WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM mistakes")
    suspend fun deleteAll()
}

@Dao
interface ScreenTimeDao {
    @Query("SELECT * FROM screen_time WHERE date = :date ORDER BY durationSeconds DESC")
    fun getScreenTimes(date: String): Flow<List<AppScreenTimeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<AppScreenTimeEntity>)

    @Query("DELETE FROM screen_time WHERE date = :date")
    suspend fun deleteForDate(date: String)

    @Query("DELETE FROM screen_time")
    suspend fun deleteAll()
}
