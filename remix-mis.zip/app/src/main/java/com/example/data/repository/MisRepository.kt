package com.example.data.repository

import android.database.sqlite.SQLiteException
import com.example.core.error.GlobalErrorHandler
import com.example.data.db.AppDatabase
import com.example.data.model.AcademicLogEntity
import com.example.data.model.AppScreenTimeEntity
import com.example.data.model.HabitEntity
import com.example.data.model.LifeLogEntity
import com.example.data.model.MistakeEntity
import com.example.data.model.Priority
import com.example.data.model.TodoItemEntity
import kotlinx.coroutines.flow.Flow
import kotlin.math.roundToInt

class MisRepository(
    private val database: AppDatabase,
    private val errorHandler: GlobalErrorHandler = GlobalErrorHandler
) {
    private val academicLogDao = database.academicLogDao()
    private val lifeLogDao = database.lifeLogDao()
    private val habitDao = database.habitDao()
    private val todoDao = database.todoDao()
    private val mistakeDao = database.mistakeDao()
    private val screenTimeDao = database.screenTimeDao()

    fun getAcademicLog(date: String): Flow<AcademicLogEntity?> =
        academicLogDao.getLogForDate(date)

    fun getAllAcademicLogs(): Flow<List<AcademicLogEntity>> =
        academicLogDao.getAllLogs()

    suspend fun saveAcademicLog(log: AcademicLogEntity, retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Commit Academic Log", retryAction) {
            academicLogDao.insertOrUpdate(log)
        }
    }

    fun getLifeLog(date: String): Flow<LifeLogEntity?> =
        lifeLogDao.getLogForDate(date)

    fun getAllLifeLogs(): Flow<List<LifeLogEntity>> =
        lifeLogDao.getAllLogs()

    suspend fun saveLifeLog(log: LifeLogEntity, retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Commit Life Sustainability Log", retryAction) {
            lifeLogDao.insertOrUpdate(log)
        }
    }

    fun getAllHabits(): Flow<List<HabitEntity>> =
        habitDao.getAllHabits()

    suspend fun addHabit(title: String, priority: String = "MEDIUM", retryAction: (() -> Unit)? = null): Result<Long> {
        return errorHandler.runCatchingDb("Add Habit Protocol", retryAction) {
            habitDao.insert(HabitEntity(title = title, priority = priority))
        }
    }

    suspend fun toggleHabit(id: Long, completed: Boolean, retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Toggle Habit Status", retryAction) {
            habitDao.setCompleted(id, completed)
        }
    }

    suspend fun updateHabitPriority(id: Long, priority: String, retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Update Habit Priority", retryAction) {
            habitDao.updatePriority(id, priority)
        }
    }

    suspend fun deleteHabit(id: Long, retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Delete Habit Protocol", retryAction) {
            habitDao.delete(id)
        }
    }

    fun getTodos(workspace: String): Flow<List<TodoItemEntity>> =
        todoDao.getTodos(workspace)

    suspend fun addTodo(
        title: String,
        subjectTag: String,
        dueDate: String,
        workspace: String,
        retryAction: (() -> Unit)? = null
    ): Result<Long> {
        return errorHandler.runCatchingDb("Add Operational Task", retryAction) {
            todoDao.insert(
                TodoItemEntity(
                    title = title,
                    subjectTag = subjectTag.ifBlank { "General" },
                    dueDate = dueDate.ifBlank { "09/08/2026" },
                    workspace = workspace
                )
            )
        }
    }

    suspend fun toggleTodo(id: Long, completed: Boolean, retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Toggle Task Status", retryAction) {
            todoDao.setCompleted(id, completed)
        }
    }

    suspend fun deleteTodo(id: Long, retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Delete Task", retryAction) {
            todoDao.delete(id)
        }
    }

    fun getAllMistakes(): Flow<List<MistakeEntity>> =
        mistakeDao.getAllMistakes()

    suspend fun addMistake(mistake: MistakeEntity, retryAction: (() -> Unit)? = null): Result<Long> {
        return errorHandler.runCatchingDb("Log Cognitive Anomaly", retryAction) {
            mistakeDao.insert(mistake)
        }
    }

    suspend fun updateMistake(mistake: MistakeEntity, retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Update Cognitive Anomaly", retryAction) {
            mistakeDao.update(mistake)
        }
    }

    suspend fun deleteMistake(id: Long, retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Delete Anomaly Record", retryAction) {
            mistakeDao.delete(id)
        }
    }

    suspend fun deleteAllMistakes(retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Purge All Anomalies", retryAction) {
            mistakeDao.deleteAll()
        }
    }

    fun getScreenTimes(date: String): Flow<List<AppScreenTimeEntity>> =
        screenTimeDao.getScreenTimes(date)

    suspend fun deleteScreenTimeForDate(date: String, retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Purge Screen Time for $date", retryAction) {
            screenTimeDao.deleteForDate(date)
        }
    }

    suspend fun deleteAllScreenTime(retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Purge Screen Time History", retryAction) {
            screenTimeDao.deleteAll()
        }
    }

    suspend fun addScreenTimeApp(
        name: String,
        seconds: Int,
        percentage: Int,
        category: String,
        date: String,
        retryAction: (() -> Unit)? = null
    ): Result<Unit> {
        return errorHandler.runCatchingDb("Log Screen Time Process", retryAction) {
            screenTimeDao.insertAll(
                listOf(
                    AppScreenTimeEntity(
                        appName = name,
                        durationSeconds = seconds,
                        percentage = percentage,
                        category = category,
                        date = date
                    )
                )
            )
        }
    }

    /**
     * Diagnostic helper for testing and validating database error handling via global Snackbar.
     */
    suspend fun simulateDatabaseError(retryAction: (() -> Unit)? = null): Result<Unit> {
        return errorHandler.runCatchingDb("Simulated SQL Query", retryAction) {
            throw SQLiteException("Disk I/O error or corrupted SQLITE table header (code 778 SQLITE_IOERR)")
        }
    }

    companion object {
        fun calculateAcademicScore(
            log: AcademicLogEntity,
            completedTasks: Int,
            totalTasks: Int
        ): Int {
            val studiesWeight = Priority.fromCode(log.studiesPriority).weight
            val tasksWeight = Priority.fromCode(log.tasksPriority).weight
            val dppWeight = Priority.fromCode(log.dppPriority).weight

            val studiesScore = (log.hoursStudied / log.targetHours.coerceAtLeast(1f)).coerceIn(0f, 1f) * 10f
            val tasksScore = if (totalTasks > 0) {
                (completedTasks.toFloat() / totalTasks.toFloat()).coerceIn(0f, 1f) * 10f
            } else 0f
            val dppScore = (log.dppCompleted.toFloat() / log.dppAssigned.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f) * 10f

            val totalWeightedScore = (studiesScore * studiesWeight) + (tasksScore * tasksWeight) + (dppScore * dppWeight)
            val totalWeight = studiesWeight + tasksWeight + dppWeight

            // Normalized to 50 points
            return if (totalWeight > 0) {
                ((totalWeightedScore / totalWeight) * 5f).roundToInt().coerceIn(0, 50)
            } else 0
        }

        fun calculateLifeScore(
            log: LifeLogEntity,
            completedHabits: Int,
            totalHabits: Int,
            completedTasks: Int,
            totalTasks: Int
        ): Int {
            val habitsWeight = Priority.fromCode(log.habitsPriority).weight
            val moodWeight = Priority.fromCode(log.moodPriority).weight
            val wellSpentWeight = Priority.fromCode(log.wellSpentPriority).weight
            val tasksWeight = Priority.fromCode(log.tasksPriority).weight

            val habitsScore = if (totalHabits > 0) {
                (completedHabits.toFloat() / totalHabits.toFloat()).coerceIn(0f, 1f) * 10f
            } else 0f
            val moodScore = log.moodScore.coerceIn(0, 10).toFloat()
            val wellSpentScore = (log.leisureMinutes.toFloat() / 60f).coerceIn(0f, 1f) * 10f
            val tasksScore = if (totalTasks > 0) {
                (completedTasks.toFloat() / totalTasks.toFloat()).coerceIn(0f, 1f) * 10f
            } else 0f

            val totalWeighted = (habitsScore * habitsWeight) + (moodScore * moodWeight) +
                    (wellSpentScore * wellSpentWeight) + (tasksScore * tasksWeight)
            val totalWeight = habitsWeight + moodWeight + wellSpentWeight + tasksWeight

            return if (totalWeight > 0) {
                ((totalWeighted / totalWeight) * 5f).roundToInt().coerceIn(0, 50)
            } else 0
        }
    }
}
