package com.example.data.repository

import com.example.core.error.GlobalErrorHandler
import com.example.data.api.ApiClient
import com.example.data.api.ApiDirectiveQuote
import com.example.data.api.MisApiService
import com.example.data.api.SyncResponse
import com.example.data.api.SyncTelemetryPayload
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.ResponseBody.Companion.toResponseBody
import retrofit2.HttpException
import retrofit2.Response
import java.io.IOException

class MisRemoteRepository(
    private val apiService: MisApiService = ApiClient.apiService
) {
    suspend fun fetchDailyQuote(retryCallback: (() -> Unit)? = null): Result<ApiDirectiveQuote> {
        return GlobalErrorHandler.runCatchingApi(
            endpointName = "Daily Quote API",
            retryAction = retryCallback
        ) {
            apiService.getDailyQuote()
        }
    }

    suspend fun syncTelemetry(
        payload: SyncTelemetryPayload,
        retryCallback: (() -> Unit)? = null
    ): Result<SyncResponse> {
        return GlobalErrorHandler.runCatchingApi(
            endpointName = "Sync Telemetry API",
            retryAction = retryCallback
        ) {
            apiService.syncTelemetry(payload)
        }
    }

    suspend fun simulateApiError(
        errorCode: Int = 503,
        retryCallback: (() -> Unit)? = null
    ): Result<Unit> {
        return GlobalErrorHandler.runCatchingApi(
            endpointName = "Cloud Intelligence Server (Simulated)",
            retryAction = retryCallback
        ) {
            val errorBody = "{\"error\": \"Service Unavailable: Gateway Timeout 503\"}"
                .toResponseBody("application/json".toMediaTypeOrNull())
            throw HttpException(Response.error<Unit>(errorCode, errorBody))
        }
    }

    suspend fun simulateNetworkError(
        retryCallback: (() -> Unit)? = null
    ): Result<Unit> {
        return GlobalErrorHandler.runCatchingApi(
            endpointName = "Cloud Gateway Connection",
            retryAction = retryCallback
        ) {
            throw java.net.ConnectException("Connection to cloud gateway failed. Host unreachable.")
        }
    }
}
