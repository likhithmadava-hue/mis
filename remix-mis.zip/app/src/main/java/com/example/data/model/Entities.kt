package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Priority(val code: String, val weight: Int, val label: String) {
    HIGH("H", 3, "High priority"),
    MEDIUM("M", 2, "Medium priority"),
    LOW("L", 1, "Low priority");

    companion object {
        fun fromCode(code: String): Priority = when (code.uppercase()) {
            "H" -> HIGH
            "M" -> MEDIUM
            "L" -> LOW
            else -> MEDIUM
        }
    }
}

@Entity(tableName = "academic_logs")
data class AcademicLogEntity(
    @PrimaryKey val date: String,
    val studiesPriority: String = "HIGH",
    val hoursStudied: Float = 0f,
    val targetHours: Float = 6f,
    val tasksPriority: String = "MEDIUM",
    val dppPriority: String = "HIGH",
    val dppAssigned: Int = 4,
    val dppCompleted: Int = 0,
    val calculatedScore: Int = 0
)

@Entity(tableName = "life_logs")
data class LifeLogEntity(
    @PrimaryKey val date: String,
    val habitsPriority: String = "HIGH",
    val moodPriority: String = "MEDIUM",
    val moodScore: Int = 5,
    val wellSpentPriority: String = "LOW",
    val leisureMinutes: Int = 0,
    val tasksPriority: String = "MEDIUM",
    val hydrationCups: Int = 0,
    val maxHydration: Int = 8,
    val postureChecks: Int = 0,
    val maxPosture: Int = 5,
    val bedtime: String = "10:30 PM",
    val wakeTime: String = "06:30 AM",
    val calculatedScore: Int = 0
)

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val priority: String = "MEDIUM",
    val isCompletedToday: Boolean = false,
    val streak: Int = 0,
    val orderIndex: Int = 0
)

@Entity(tableName = "todos")
data class TodoItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subjectTag: String = "General",
    val dueDate: String = "09/08/2026",
    val isCompleted: Boolean = false,
    val workspace: String = "ACADEMIC"
)

@Entity(tableName = "mistakes")
data class MistakeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subject: String,
    val chapter: String,
    val errorType: String,
    val difficulty: String,
    val marksLost: Int = 1,
    val notes: String = "",
    val dateAdded: String = "2026-09-08"
)

@Entity(tableName = "screen_time")
data class AppScreenTimeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val appName: String,
    val durationSeconds: Int,
    val percentage: Int,
    val category: String = "Utility",
    val date: String = "2026-09-08"
)
