package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.AcademicLogEntity
import com.example.data.model.AppScreenTimeEntity
import com.example.data.model.HabitEntity
import com.example.data.model.LifeLogEntity
import com.example.data.model.MistakeEntity
import com.example.data.model.TodoItemEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        AcademicLogEntity::class,
        LifeLogEntity::class,
        HabitEntity::class,
        TodoItemEntity::class,
        MistakeEntity::class,
        AppScreenTimeEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun academicLogDao(): AcademicLogDao
    abstract fun lifeLogDao(): LifeLogDao
    abstract fun habitDao(): HabitDao
    abstract fun todoDao(): TodoDao
    abstract fun mistakeDao(): MistakeDao
    abstract fun screenTimeDao(): ScreenTimeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mis_database.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed initial data matching reference video
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = getDatabase(context)
                            seedInitialData(database)
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedInitialData(database: AppDatabase) {
            val today = "2026-09-08"
            // Seed habits from video
            database.habitDao().insertAll(
                listOf(
                    HabitEntity(title = "Read 20 pages", priority = "MEDIUM", isCompletedToday = false, streak = 0, orderIndex = 0),
                    HabitEntity(title = "Revise yesterday", priority = "HIGH", isCompletedToday = false, streak = 0, orderIndex = 1),
                    HabitEntity(title = "Morning workout", priority = "LOW", isCompletedToday = false, streak = 0, orderIndex = 2),
                    HabitEntity(title = "No phone in bed", priority = "HIGH", isCompletedToday = false, streak = 0, orderIndex = 3)
                )
            )

            // Seed initial screen time from video
            database.screenTimeDao().insertAll(
                listOf(
                    AppScreenTimeEntity(appName = "mis.exe", durationSeconds = 30, percentage = 55, category = "Focus/MIS", date = today),
                    AppScreenTimeEntity(appName = "snippingtool.exe", durationSeconds = 25, percentage = 45, category = "Utility", date = today)
                )
            )

            // Seed initial daily logs
            database.academicLogDao().insertOrUpdate(
                AcademicLogEntity(
                    date = today,
                    studiesPriority = "HIGH",
                    hoursStudied = 0f,
                    targetHours = 6f,
                    tasksPriority = "MEDIUM",
                    dppPriority = "HIGH",
                    dppAssigned = 4,
                    dppCompleted = 0,
                    calculatedScore = 0
                )
            )

            database.lifeLogDao().insertOrUpdate(
                LifeLogEntity(
                    date = today,
                    habitsPriority = "HIGH",
                    moodPriority = "MEDIUM",
                    moodScore = 5,
                    wellSpentPriority = "LOW",
                    leisureMinutes = 0,
                    tasksPriority = "MEDIUM",
                    hydrationCups = 0,
                    maxHydration = 8,
                    postureChecks = 0,
                    maxPosture = 5,
                    bedtime = "10:30 PM",
                    wakeTime = "06:30 AM",
                    calculatedScore = 0
                )
            )
        }
    }
}
