package com.example.core.error

import android.util.Log
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import kotlin.coroutines.cancellation.CancellationException

/**
 * Domain-specific error representations for MIS operations.
 */
sealed class AppError(
    open val message: String,
    open val cause: Throwable? = null
) {
    data class DatabaseError(
        override val message: String,
        val operation: String = "Database Operation",
        override val cause: Throwable? = null
    ) : AppError(message, cause)

    data class ApiError(
        override val message: String,
        val statusCode: Int? = null,
        val endpoint: String? = null,
        override val cause: Throwable? = null
    ) : AppError(message, cause)

    data class NetworkError(
        override val message: String = "Network connection unavailable. Please check your connectivity.",
        override val cause: Throwable? = null
    ) : AppError(message, cause)

    data class UnexpectedError(
        override val message: String,
        override val cause: Throwable? = null
    ) : AppError(message, cause)
}

/**
 * Error payload emitted to UI for presentation via global Snackbar.
 */
data class ErrorEvent(
    val id: Long = System.currentTimeMillis(),
    val error: AppError,
    val message: String = error.message,
    val actionLabel: String? = null,
    val onAction: (() -> Unit)? = null
)

/**
 * Centralized global error handler across Database, API, and Coroutine operations.
 */
object GlobalErrorHandler {
    private const val TAG = "GlobalErrorHandler"

    private val _errorEvents = MutableSharedFlow<ErrorEvent>(
        replay = 0,
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val errorEvents: SharedFlow<ErrorEvent> = _errorEvents.asSharedFlow()

    /**
     * Dispatch an error to be displayed on the global Snackbar.
     */
    fun notifyError(
        error: AppError,
        actionLabel: String? = null,
        onAction: (() -> Unit)? = null
    ) {
        Log.e(TAG, "Notifying error: ${error.message}", error.cause)
        val event = ErrorEvent(
            error = error,
            message = error.message,
            actionLabel = actionLabel,
            onAction = onAction
        )
        _errorEvents.tryEmit(event)
    }

    /**
     * Convenience method to notify with a plain message string.
     */
    fun notifyError(
        message: String,
        actionLabel: String? = null,
        onAction: (() -> Unit)? = null
    ) {
        notifyError(
            error = AppError.UnexpectedError(message),
            actionLabel = actionLabel,
            onAction = onAction
        )
    }

    /**
     * Executes a database block with standardized error catching and global Snackbar notification.
     */
    suspend fun <T> runCatchingDb(
        operationName: String = "Database Operation",
        retryAction: (() -> Unit)? = null,
        block: suspend () -> T
    ): Result<T> {
        return try {
            val result = block()
            Result.success(result)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val rawMsg = e.localizedMessage ?: e.message ?: "Storage operation failed"
            val displayMessage = "Database Error [$operationName]: $rawMsg"
            Log.e(TAG, "DB Failure during $operationName", e)

            val error = AppError.DatabaseError(
                message = displayMessage,
                operation = operationName,
                cause = e
            )
            notifyError(
                error = error,
                actionLabel = if (retryAction != null) "RETRY" else "DISMISS",
                onAction = retryAction
            )
            Result.failure(e)
        }
    }

    /**
     * Executes a network / API block with standardized HTTP/Network error catching and global Snackbar notification.
     */
    suspend fun <T> runCatchingApi(
        endpointName: String = "API Call",
        retryAction: (() -> Unit)? = null,
        block: suspend () -> T
    ): Result<T> {
        return try {
            val result = block()
            Result.success(result)
        } catch (e: CancellationException) {
            throw e
        } catch (e: UnknownHostException) {
            val displayMessage = "Network Error [$endpointName]: Unable to reach host. Check connection."
            Log.e(TAG, "UnknownHostException for $endpointName", e)
            val error = AppError.NetworkError(message = displayMessage, cause = e)
            notifyError(error = error, actionLabel = if (retryAction != null) "RETRY" else "DISMISS", onAction = retryAction)
            Result.failure(e)
        } catch (e: ConnectException) {
            val displayMessage = "Network Error [$endpointName]: Server connection refused."
            Log.e(TAG, "ConnectException for $endpointName", e)
            val error = AppError.NetworkError(message = displayMessage, cause = e)
            notifyError(error = error, actionLabel = if (retryAction != null) "RETRY" else "DISMISS", onAction = retryAction)
            Result.failure(e)
        } catch (e: SocketTimeoutException) {
            val displayMessage = "Network Error [$endpointName]: Connection timed out."
            Log.e(TAG, "SocketTimeoutException for $endpointName", e)
            val error = AppError.NetworkError(message = displayMessage, cause = e)
            notifyError(error = error, actionLabel = if (retryAction != null) "RETRY" else "DISMISS", onAction = retryAction)
            Result.failure(e)
        } catch (e: retrofit2.HttpException) {
            val code = e.code()
            val displayMessage = "API Error [$endpointName]: HTTP $code ${e.message()}"
            Log.e(TAG, "HttpException for $endpointName: $code", e)
            val error = AppError.ApiError(message = displayMessage, statusCode = code, endpoint = endpointName, cause = e)
            notifyError(error = error, actionLabel = if (retryAction != null) "RETRY" else "DISMISS", onAction = retryAction)
            Result.failure(e)
        } catch (e: IOException) {
            val displayMessage = "I/O Error [$endpointName]: ${e.localizedMessage ?: "Communication failure"}"
            Log.e(TAG, "IOException for $endpointName", e)
            val error = AppError.NetworkError(message = displayMessage, cause = e)
            notifyError(error = error, actionLabel = if (retryAction != null) "RETRY" else "DISMISS", onAction = retryAction)
            Result.failure(e)
        } catch (e: Exception) {
            val rawMsg = e.localizedMessage ?: e.message ?: "Request failed"
            val displayMessage = "API Error [$endpointName]: $rawMsg"
            Log.e(TAG, "General Exception during $endpointName", e)
            val error = AppError.ApiError(message = displayMessage, endpoint = endpointName, cause = e)
            notifyError(error = error, actionLabel = if (retryAction != null) "RETRY" else "DISMISS", onAction = retryAction)
            Result.failure(e)
        }
    }

    /**
     * Coroutine exception handler for uncaught exceptions in view models or background jobs.
     */
    fun coroutineExceptionHandler(contextName: String = "AppCoroutines"): CoroutineExceptionHandler {
        return CoroutineExceptionHandler { _, throwable ->
            if (throwable !is CancellationException) {
                Log.e(TAG, "Uncaught exception in $contextName", throwable)
                notifyError(
                    error = AppError.UnexpectedError(
                        message = "System Exception [$contextName]: ${throwable.localizedMessage ?: "Unexpected fault"}",
                        cause = throwable
                    )
                )
            }
        }
    }
}
