package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.core.error.GlobalErrorHandler
import com.example.ui.components.MisErrorSnackbar
import com.example.ui.components.ModeSwitcher
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import com.example.ui.components.PulseBeacon
import com.example.ui.screens.academic.AcademicDailyLogScreen
import com.example.ui.screens.academic.AcademicHomeScreen
import com.example.ui.screens.academic.DatabaseScreen
import com.example.ui.screens.academic.FocusTimerScreen
import com.example.ui.screens.common.ReportScreen
import com.example.ui.screens.life.LifeDailyLogScreen
import com.example.ui.screens.life.LifeHomeScreen
import com.example.ui.screens.life.ScreenTimeScreen
import com.example.ui.theme.LocalMisTheme
import com.example.ui.theme.MisAppTheme
import com.example.ui.theme.MisBg900
import com.example.ui.theme.MisBg950
import com.example.ui.theme.MisBorderSubtle
import com.example.ui.theme.MisTextDim
import com.example.ui.theme.MisTextMuted
import com.example.ui.theme.MisTextPrimary
import com.example.ui.theme.MisWorkspace
import com.example.ui.viewmodel.MisDestination
import com.example.ui.viewmodel.MisViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val app = context.applicationContext as Application
            val misViewModel: MisViewModel = viewModel(
                factory = MisViewModel.Factory(app)
            )
            MisApp(viewModel = misViewModel)
        }
    }
}

data class NavItem(
    val destination: MisDestination,
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

@Composable
fun MisApp(viewModel: MisViewModel) {
    val currentWorkspace by viewModel.workspace.collectAsState()
    val currentDestination by viewModel.currentDestination.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        GlobalErrorHandler.errorEvents.collectLatest { event ->
            coroutineScope.launch {
                snackbarHostState.currentSnackbarData?.dismiss()
                val result = snackbarHostState.showSnackbar(
                    message = event.message,
                    actionLabel = event.actionLabel,
                    duration = if (event.actionLabel != null) SnackbarDuration.Long else SnackbarDuration.Short
                )
                if (result == SnackbarResult.ActionPerformed) {
                    event.onAction?.invoke()
                }
            }
        }
    }

    MisAppTheme(workspace = currentWorkspace) {
        val accentColor = LocalMisTheme.current.accentPrimary
        val accentGlow = LocalMisTheme.current.accentGlow

        // Dynamic navigation items based on workspace
        val navItems = when (currentWorkspace) {
            MisWorkspace.ACADEMIC -> listOf(
                NavItem(MisDestination.HOME, "Home", Icons.Default.Home, "nav_home"),
                NavItem(MisDestination.DAILY_LOG, "Daily Log", Icons.Default.Assignment, "nav_daily_log"),
                NavItem(MisDestination.DATABASE, "Database", Icons.Default.Storage, "nav_database"),
                NavItem(MisDestination.FOCUS_TIMER, "Focus", Icons.Default.Timer, "nav_focus"),
                NavItem(MisDestination.REPORT, "Report", Icons.Default.BarChart, "nav_report")
            )
            MisWorkspace.LIFE -> listOf(
                NavItem(MisDestination.HOME, "Home", Icons.Default.Home, "nav_home"),
                NavItem(MisDestination.DAILY_LOG, "Daily Log", Icons.Default.Assignment, "nav_daily_log"),
                NavItem(MisDestination.REPORT, "Report", Icons.Default.BarChart, "nav_report"),
                NavItem(MisDestination.SCREEN_TIME, "Screen Time", Icons.Default.Schedule, "nav_screen_time")
            )
        }

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MisBg950,
            snackbarHost = {
                SnackbarHost(
                    hostState = snackbarHostState,
                    modifier = Modifier.testTag("global_snackbar_host")
                ) { snackbarData ->
                    MisErrorSnackbar(snackbarData = snackbarData)
                }
            },
            topBar = {
                // Top MIS Control Bar with Mode Switcher
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.statusBars)
                        .background(MisBg950)
                        .drawBehind {
                            // Hairline border below top bar
                            drawLine(
                                color = MisBorderSubtle,
                                start = Offset(0f, size.height),
                                end = Offset(size.width, size.height),
                                strokeWidth = 1f
                            )
                        }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // MIS Brand Badge with live pulse beacon
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MisBg900)
                                    .border(
                                        BorderStroke(
                                            1.dp,
                                            Brush.horizontalGradient(
                                                listOf(accentColor.copy(alpha = 0.5f), MisBorderSubtle)
                                            )
                                        ),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    PulseBeacon(color = accentColor, size = 6)
                                    Text(
                                        text = "MIS",
                                        fontSize = 13.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 2.sp,
                                        color = accentColor
                                    )
                                }
                            }

                            Text(
                                text = "SYSTEM // LIVE",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 1.2.sp,
                                color = MisTextDim
                            )
                        }

                        // Mode Segmented Switcher
                        ModeSwitcher(
                            currentWorkspace = currentWorkspace,
                            onWorkspaceChanged = { viewModel.setWorkspace(it) }
                        )
                    }
                }
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MisBg950,
                    tonalElevation = 0.dp,
                    modifier = Modifier
                        .drawBehind {
                            // Top edge glowing highlight line for navigation dock
                            val glowBrush = Brush.horizontalGradient(
                                listOf(
                                    Color.Transparent,
                                    accentColor.copy(alpha = 0.35f),
                                    accentColor.copy(alpha = 0.6f),
                                    accentColor.copy(alpha = 0.35f),
                                    Color.Transparent
                                )
                            )
                            drawLine(
                                brush = glowBrush,
                                start = Offset(0f, 0f),
                                end = Offset(size.width, 0f),
                                strokeWidth = 2f
                            )
                        }
                        .border(1.dp, MisBorderSubtle)
                        .height(64.dp)
                ) {
                    navItems.forEach { item ->
                        val isSelected = currentDestination == item.destination
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { viewModel.navigateTo(item.destination) },
                            icon = {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.label,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = item.label,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = accentColor,
                                selectedTextColor = accentColor,
                                unselectedIconColor = MisTextDim,
                                unselectedTextColor = MisTextDim,
                                indicatorColor = accentGlow
                            ),
                            modifier = Modifier.testTag(item.testTag)
                        )
                    }
                }
            }
        ) { innerPadding ->
            AnimatedContent(
                targetState = Pair(currentWorkspace, currentDestination),
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                label = "ScreenTransition"
            ) { (workspace, destination) ->
                when (destination) {
                    MisDestination.HOME -> {
                        if (workspace == MisWorkspace.ACADEMIC) {
                            AcademicHomeScreen(viewModel = viewModel)
                        } else {
                            LifeHomeScreen(viewModel = viewModel)
                        }
                    }
                    MisDestination.DAILY_LOG -> {
                        if (workspace == MisWorkspace.ACADEMIC) {
                            AcademicDailyLogScreen(viewModel = viewModel)
                        } else {
                            LifeDailyLogScreen(viewModel = viewModel)
                        }
                    }
                    MisDestination.DATABASE -> {
                        DatabaseScreen(viewModel = viewModel)
                    }
                    MisDestination.FOCUS_TIMER -> {
                        FocusTimerScreen(viewModel = viewModel)
                    }
                    MisDestination.REPORT -> {
                        ReportScreen(viewModel = viewModel)
                    }
                    MisDestination.SCREEN_TIME -> {
                        ScreenTimeScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Greeting("Android")
}
