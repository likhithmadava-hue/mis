package com.example

import android.database.sqlite.SQLiteException
import com.example.core.error.AppError
import com.example.core.error.GlobalErrorHandler
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import retrofit2.HttpException
import retrofit2.Response
import java.net.ConnectException
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GlobalErrorHandlerTest {

    @Test
    fun `notifyError emits ErrorEvent with custom message and action`() = runTest {
        val errorFlow = async { GlobalErrorHandler.errorEvents.first() }

        var retryCalled = false
        GlobalErrorHandler.notifyError(
            error = AppError.DatabaseError("Corrupt table anomaly", operation = "MistakeDAO"),
            actionLabel = "RETRY",
            onAction = { retryCalled = true }
        )

        val event = errorFlow.await()
        assertEquals("Corrupt table anomaly", event.message)
        assertEquals("RETRY", event.actionLabel)
        assertTrue(event.error is AppError.DatabaseError)

        event.onAction?.invoke()
        assertTrue(retryCalled)
    }

    @Test
    fun `runCatchingDb catches SQLiteException and triggers DatabaseError notification`() = runTest {
        val errorFlow = async { GlobalErrorHandler.errorEvents.first() }
        var retryTriggered = false

        val result = GlobalErrorHandler.runCatchingDb(
            operationName = "Insert Academic Record",
            retryAction = { retryTriggered = true }
        ) {
            throw SQLiteException("Disk I/O failure on commit")
        }

        assertTrue(result.isFailure)
        val event = errorFlow.await()
        assertTrue(event.message.contains("Insert Academic Record"))
        assertTrue(event.message.contains("Disk I/O failure on commit"))
        assertEquals("RETRY", event.actionLabel)
        assertTrue(event.error is AppError.DatabaseError)

        event.onAction?.invoke()
        assertTrue(retryTriggered)
    }

    @Test
    fun `runCatchingApi catches ConnectException and maps to NetworkError`() = runTest {
        val errorFlow = async { GlobalErrorHandler.errorEvents.first() }

        val result = GlobalErrorHandler.runCatchingApi(
            endpointName = "Telemetry Cloud Service",
            retryAction = { }
        ) {
            throw ConnectException("Connection refused to internal gateway")
        }

        assertTrue(result.isFailure)
        val event = errorFlow.await()
        assertTrue(event.error is AppError.NetworkError)
        assertTrue(event.message.contains("Server connection refused"))
        assertEquals("RETRY", event.actionLabel)
    }

    @Test
    fun `runCatchingApi catches HttpException and maps to ApiError with status code`() = runTest {
        val errorFlow = async { GlobalErrorHandler.errorEvents.first() }

        val httpException = HttpException(
            Response.error<Unit>(503, "Service Unavailable".toResponseBody())
        )

        val result = GlobalErrorHandler.runCatchingApi(
            endpointName = "Directive Sync Gateway",
            retryAction = { }
        ) {
            throw httpException
        }

        assertTrue(result.isFailure)
        val event = errorFlow.await()
        assertTrue(event.error is AppError.ApiError)
        val apiError = event.error as AppError.ApiError
        assertEquals(503, apiError.statusCode)
        assertTrue(event.message.contains("HTTP 503"))
    }
}
