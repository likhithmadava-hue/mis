package com.example

import androidx.compose.material3.SnackbarData
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarVisuals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.example.ui.components.MisErrorSnackbar
import com.example.ui.theme.MisAppTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GlobalSnackbarUiTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `misErrorSnackbar displays error message and performs retry action`() {
        var actionTriggered = false
        var dismissTriggered = false

        val testVisuals = object : SnackbarVisuals {
            override val message: String = "Database Error [Commit Habit]: SQLite failure"
            override val actionLabel: String = "RETRY"
            override val withDismissAction: Boolean = true
            override val duration: SnackbarDuration = SnackbarDuration.Long
        }

        val testSnackbarData = object : SnackbarData {
            override val visuals: SnackbarVisuals = testVisuals
            override fun performAction() {
                actionTriggered = true
            }
            override fun dismiss() {
                dismissTriggered = true
            }
        }

        composeTestRule.setContent {
            MisAppTheme {
                MisErrorSnackbar(snackbarData = testSnackbarData)
            }
        }

        composeTestRule.onNodeWithTag("global_mis_snackbar").assertIsDisplayed()
        composeTestRule.onNodeWithText("SYSTEM EXCEPTION //").assertIsDisplayed()
        composeTestRule.onNodeWithTag("snackbar_message_text").assertIsDisplayed()
        composeTestRule.onNodeWithText("Database Error [Commit Habit]: SQLite failure").assertIsDisplayed()

        composeTestRule.onNodeWithTag("snackbar_action_button").assertIsDisplayed().performClick()
        assertTrue(actionTriggered)

        composeTestRule.onNodeWithTag("snackbar_dismiss_button").assertIsDisplayed().performClick()
        assertTrue(dismissTriggered)
    }
}
